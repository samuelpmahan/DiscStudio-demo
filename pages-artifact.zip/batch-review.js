import { queueCards, validateCardAppearance, validateU01Appearance,                                                          } from './export-queue-core.js?v=47fa46ba73c1842b';
                                                                              

                                                                                                                                                                                                                                                      
                                                                                                  
                                                                                                                 
export const CARD_SETUP_STORAGE_KEY = 'discstudio.card-setup.v1';

export function validateSavedSetup(value         )                 {
  const setup = value       , placement = setup?.placement;
  if (!setup || setup.version !== 1 || typeof setup.name !== 'string' || !setup.name.trim()) throw Error('Saved setup needs a name.');
  if (!['vertical', 'horizontal'].includes(setup.orientation)) throw Error('Saved setup has an invalid orientation.');
  if (typeof setup.preset !== 'string' || !/^(?:u0[1-5]|u03-(?:front|behind)(?:-mirror)?|b0[1-5])$/.test(setup.preset) || (setup.orientation === 'vertical' ? setup.preset[0] !== 'u' : setup.preset[0] !== 'b')) throw Error('Saved setup has an invalid card layout.');
  if (!placement || ![placement.scale, placement.dx, placement.dy].every(Number.isFinite) || placement.scale < .5 || placement.scale > 1.5 || Math.abs(placement.dx) > 1 || Math.abs(placement.dy) > 1) throw Error('Saved setup has an invalid placement.');
  const u01Appearance = setup.u01Appearance === undefined ? undefined : validateU01Appearance(setup.u01Appearance);
  const cardAppearance = setup.cardAppearance === undefined ? undefined : validateCardAppearance(setup.cardAppearance);
  if (u01Appearance && cardAppearance) throw Error('Saved setup has conflicting appearance fields.');
  return Object.freeze({ version: 1, name: setup.name.trim(), preset: setup.preset, orientation: setup.orientation, placement: Object.freeze({ scale: placement.scale, dx: placement.dx, dy: placement.dy }), ...(cardAppearance ? { cardAppearance } : {}), ...(u01Appearance ? { u01Appearance } : {}) });
}
export function loadSavedSetup(storage                                             )                        {
  try { const raw = storage?.getItem(CARD_SETUP_STORAGE_KEY); return raw ? validateSavedSetup(JSON.parse(raw)) : null; } catch { return null; }
}
export function storeSavedSetup(storage                          , setup         )                 {
  const valid = validateSavedSetup(setup); storage.setItem(CARD_SETUP_STORAGE_KEY, JSON.stringify(valid)); return valid;
}
export function makeReviewCandidates(cards                       )                             {
  return queueCards(cards).map((card, index) => Object.freeze({ id: `${card.disc.id}:${index}`, card, state: 'rendering' }));
}
export function transitionCandidate(candidates                            , id        , state                , reason         )                             {
  return candidates.map(candidate => candidate.id !== id || candidate.state === 'approved' ? candidate : Object.freeze({ ...candidate, state, ...(reason ? { reason } : {}) }));
}
export function pendingCards(candidates                            )                        { return candidates.filter(candidate => candidate.state === 'ready').map(candidate => candidate.card); }
