// SpotlightCard renderer for Disc Studio MVP.
// Each disc in the bag gets an individual card: full-frame transparent PNG
// with the card baked at the bottom-left corner (CapCut overlay track).
// Visual hierarchy: PHOTO > MOLDNAME >> NUMBERS >>> everything else.

import { createFrameRenderer } from './frame-seek.mjs?v=6277f3a3c0ce0b38';
                                       
import { DEFAULT_U01_APPEARANCE, validateU01Appearance,                    } from './export-queue-core.js?v=6277f3a3c0ce0b38';

                                     
                                              
                                                
                        
                                                        
                                                         
                                   
  
                                                                                                                                            

                                                        

export const CARD_SIZE                                                    = {
  horizontal: { w: 1920, h: 1080 },
  vertical: { w: 1080, h: 1920 },
};

const CARD_BG = 'rgba(14,18,22,0.94)';
const INK = '#ffffff';
const MINT = '#8fe3ae';
const FONT_STACK = '"DejaVu Sans", "Nimbus Sans", system-ui, -apple-system, "Segoe UI", Arial, sans-serif';

                     
                                        
                                           
                  
                        
                                                                  
                          
  

function moldIdFromAddress(address        )         {
  const m = /^ds\.px\.seed\.([^.]+)/.exec(address);
  return m ? m[1] : address;
}

export async function resolveCardDisc(environment                       , disc              )                        {
  const id = moldIdFromAddress(disc.mold);
  const supplied = disc.renderer ?? {};
  let moldName = supplied.moldName ?? id;
  let manufacturer = supplied.manufacturer ?? '';
  let flights                           = Array.isArray(supplied.flights) ? supplied.flights : null;
  try {
    const details      = environment.getMoldDetails ? await environment.getMoldDetails(id) : null;
    if (details) {
      // A queued card holds renderer facts at enqueue time. Catalog lookup can
      // fill a missing value, never replace the held card's provenance.
      if (supplied.moldName === undefined) moldName = details.mold ?? details.name ?? moldName;
      if (supplied.manufacturer === undefined) manufacturer = details.manufacturer ?? manufacturer;
      if (!Array.isArray(supplied.flights) && Array.isArray(details.flight)) flights = details.flight;
    }
  } catch {
    // Browser exports retain their passed-in model facts when detail lookup is unavailable.
  }
  const fields = ['speed', 'glide', 'turn', 'fade']         ;
  // An absent field inherits the mold. An explicitly retained null means the
  // player marked that value unknown; it must never silently fall back.
  if (fields.some(field => Object.hasOwn(disc, field) && disc[field] !== undefined)) {
    const base = Array.isArray(flights) ? [...flights] : [null, null, null, null];
    flights = base.map((value, index) => Object.hasOwn(disc, fields[index]) && disc[fields[index]] !== undefined ? (disc[fields[index]] ?? null) : value);
  }
  return {
    moldName,
    manufacturer,
    plastic: disc.plastic || '',
    weight: disc.weight ?? null,
    flights,
    photoSrc: disc.depiction?.kind === 'photo' ? disc.depiction.src ?? null : disc.depiction?.kind === 'painted' && supplied.artSrc?.startsWith('data:image/svg+xml;') ? supplied.artSrc : null,
  };
}

/** Shrink font until text fits maxWidth. Returns the font string to use. */
function fitFont(ctx     , text        , maxWidth        , weight        , startPx        , family = FONT_STACK)         {
  let px = startPx;
  while (px > 12) {
    ctx.font = `${weight} ${px}px ${family}`;
    if (ctx.measureText(text).width <= maxWidth) break;
    px -= 4;
  }
  return ctx.font;
}

function roundRect(ctx     , x        , y        , w        , h        , r        ) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/** Draw image cover-fit inside a circle. Falls back to a placeholder ring. */
function accentRgba(hex        , alpha        )         {
  const value = hex.slice(1);
  const rgb = [0, 2, 4].map(index => Number.parseInt(value.slice(index, index + 2), 16));
  return `rgba(${rgb[0]},${rgb[1]},${rgb[2]},${alpha})`;
}

async function drawPhotoCircle(environment                       , ctx     , src               , cx        , cy        , d        , accent         ) {
  const r = d / 2;
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.clip();
  let drew = false;
  if (src) {
    try {
      const img = await environment.loadImage(src);
      // cover-fit: scale to fill, center-crop
      const scale = Math.max(d / img.width, d / img.height);
      const w = img.width * scale, h = img.height * scale;
      ctx.drawImage(img, cx - w / 2, cy - h / 2, w, h);
      drew = true;
    } catch (error) {
      if (environment.strictPhoto) throw new Error(`Prepared photo could not be decoded for export: ${String(error)}`);
      drew = false;
    }
  }
  if (!drew) {
    // Placeholder: dark disc with inner ring, like an unprinted disc.
    ctx.fillStyle = '#1c2a24';
    ctx.fillRect(cx - r, cy - r, d, d);
    ctx.strokeStyle = accent ? accentRgba(accent, 0.35) : 'rgba(143,227,174,0.35)';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(cx, cy, r * 0.62, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
  // Mint rim around the photo, echoing the deck's disc-mark ring.
  ctx.strokeStyle = accent ? accentRgba(accent, 0.9) : 'rgba(143,227,174,0.9)';
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.stroke();
}

function plasticWeightLine(rd              )         {
  const parts           = [];
  if (rd.plastic) parts.push(rd.plastic);
  if (rd.weight !== null && rd.weight !== undefined) parts.push(`${rd.weight}g`);
  return parts.join(' · ');
}

function flightsLine(rd              )                {
  if (!rd.flights || !rd.flights.some(v => v !== null && v !== undefined)) return null;
  return rd.flights.map(v => (v === null || v === undefined ? '?' : String(v))).join('   ');
}

async function drawHorizontal(environment                       , ctx     , rd              ) {
  const M = 48;
  const cardW = 1100, cardH = 440;
  const cardX = M, cardY = 1080 - M - cardH;
  ctx.fillStyle = CARD_BG;
  roundRect(ctx, cardX, cardY, cardW, cardH, 40);
  ctx.fill();

  // Photo: hero, left.
  const d = 360;
  const cx = cardX + 48 + d / 2, cy = cardY + cardH / 2;
  await drawPhotoCircle(environment, ctx, rd.photoSrc, cx, cy, d);

  // Text block: right of photo.
  const tx = cardX + 48 + d + 56;
  const maxW = cardX + cardW - 48 - tx;
  ctx.textBaseline = 'alphabetic';

  const name = rd.moldName.toUpperCase();
  ctx.fillStyle = INK;
  fitFont(ctx, name, maxW, 800, 124);
  ctx.fillText(name, tx, cardY + 196);

  const pw = plasticWeightLine(rd);
  if (pw) {
    ctx.fillStyle = MINT;
    ctx.font = `500 42px ${FONT_STACK}`;
    ctx.fillText(pw, tx, cardY + 272);
  }

  const fl = flightsLine(rd);
  if (fl) {
    ctx.fillStyle = MINT;
    ctx.font = `600 54px ${FONT_STACK}`;
    ctx.fillText(fl, tx, cardY + 356);
  }
}

async function drawVertical(environment                       , ctx     , rd              ) {
  const M = 48;
  const cardW = 1080 - M * 2, cardH = 780;
  const cardX = M, cardY = 1920 - M - cardH;
  ctx.fillStyle = CARD_BG;
  roundRect(ctx, cardX, cardY, cardW, cardH, 40);
  ctx.fill();

  // Photo: hero, centered top.
  const d = 330;
  const cx = cardX + cardW / 2, cy = cardY + 56 + d / 2;
  await drawPhotoCircle(environment, ctx, rd.photoSrc, cx, cy, d);

  // Text: centered below photo.
  ctx.textAlign = 'center';
  const midX = cardX + cardW / 2;
  const photoBottom = cardY + 56 + d;

  const name = rd.moldName.toUpperCase();
  ctx.fillStyle = INK;
  fitFont(ctx, name, cardW - 96, 800, 104);
  ctx.fillText(name, midX, photoBottom + 122);

  const pw = plasticWeightLine(rd);
  let y = photoBottom + 122;
  if (pw) {
    ctx.fillStyle = MINT;
    ctx.font = `500 40px ${FONT_STACK}`;
    ctx.fillText(pw, midX, y + 64);
    y += 64;
  }

  const fl = flightsLine(rd);
  if (fl) {
    ctx.fillStyle = MINT;
    ctx.font = `600 52px ${FONT_STACK}`;
    ctx.fillText(fl, midX, y + 78);
  }
  ctx.textAlign = 'left';
}

/* ------------------------------------------------------------------
 * UPRIGHT PRESETS (vertical-native, 9:16) — from Spotlight_Card_Visual_Research.
 * Safe areas: top 14% platform UI, bottom 25% captions/controls,
 * right 12% action rail. Key info lives in the 15-70% height guide.
 * Breakout (horizontal) presets register into the same `presetRenderers`
 * registry under b01..b05; renderCard dispatches on the preset id.
 * ------------------------------------------------------------------ */

                                                                                                                                                                               

/** Preset id -> renderer. Breakout presets (b01..b05) register here too. */
export const presetRenderers                                                                                                                                   = {};

const VW = 1080, VH = 1920;
const Z_TOP = VH * 0.14;   // platform UI dead zone
const Z_BOT = VH * 0.75;   // caption/controls dead zone
const Z_RAIL = VW * 0.88;  // action rail starts here (right 12%)
const NIGHT92 = 'rgba(5,7,6,0.92)';
const NIGHT94 = 'rgba(5,7,6,0.94)';
const ACID = '#c8f23d';
const CORAL = '#ff5c47';
const DISPLAY = '"DejaVu Sans Condensed", "Nimbus Sans Narrow", "DejaVu Sans", sans-serif';
const SCOREBUG_SURFACE = '#1a1b1a';

function luminance(hex        )         {
  const channels = [0, 2, 4].map(index => Number.parseInt(hex.slice(1 + index, 3 + index), 16) / 255);
  return channels.map(channel => channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4).reduce((sum, channel, index) => sum + channel * [0.2126, 0.7152, 0.0722][index], 0);
}

function contrastRatio(first        , second        )         {
  const values = [luminance(first), luminance(second)].sort((a, b) => b - a);
  return (values[0] + 0.05) / (values[1] + 0.05);
}

export function u01AccentContrastOnScorebug(accent        )         { return contrastRatio(accent, SCOREBUG_SURFACE); }

function flightTiles(rd              )           {
  if (!rd.flights) return [];
  return rd.flights.map(v => (v === null || v === undefined ? '?' : String(v)));
}

function tilesRowWidth(n        , tile        , gap        )         {
  return n * tile + Math.max(0, n - 1) * gap;
}

/** Law 5: numbers are objects. Left/right/center aligned tile row. */
function drawTilesRow(
  ctx     , nums          , x        , y        ,
  tile        , gap        , fontPx        ,
  align                              = 'left',
  fill = 'rgba(255,255,255,0.10)',
  ink = '#0e1216',
  fitDigits = false,
) {
  const total = tilesRowWidth(nums.length, tile, gap);
  let sx = x;
  if (align === 'right') sx = x - total;
  if (align === 'center') sx = x - total / 2;
  ctx.font = `600 ${fontPx}px ${FONT_STACK}`;
  for (let i = 0; i < nums.length; i++) {
    const bx = sx + i * (tile + gap);
    ctx.fillStyle = fill;
    roundRect(ctx, bx, y, tile, tile, 10);
    ctx.fill();
    // The caller pairs each tile fill with a contrasting value color.
    ctx.fillStyle = ink;
    if (fitDigits) fitFont(ctx, nums[i], tile - 12, 600, fontPx);
    ctx.textAlign = 'center';
    ctx.fillText(nums[i], bx + tile / 2, y + tile * 0.72);
  }
  ctx.textAlign = 'left';
}

function contrastInk(hex        )         {
  if (contrastRatio(hex, '#111820') >= 4.5) return '#111820';
  return contrastRatio(hex, '#000000') >= contrastRatio(hex, '#ffffff') ? '#000000' : '#ffffff';
}

function drawU01FlightValues(ctx     , nums          , x        , y        , align                  , highlightTarget                    , accent        ) {
  const defaultTile = '#38413e';
  const digitTile = contrastRatio(accent, defaultTile) >= 4.5 ? defaultTile : contrastInk(accent);
  drawTilesRow(ctx, nums, x, y, 64, 10, 38, align, highlightTarget === 'tiles' ? accent : digitTile, highlightTarget === 'digits' ? accent : contrastInk(accent));
}

/** Law 4: one display voice for the name. */
function drawPresetName(
  ctx     , text        , x        , y        ,
  maxW        , startPx        , align                              = 'left',
) {
  const name = text.toUpperCase();
  ctx.fillStyle = INK;
  fitFont(ctx, name, maxW, 800, startPx, DISPLAY);
  ctx.textAlign = align;
  ctx.fillText(name, x, y);
  ctx.textAlign = 'left';
}

/** U01 Compact Scorebug (NFL on Fox, corner card).
 * Card footprint: x 48-508, y ~410-1060. A slim dark scorebug anchors in the
 * safe left; the disc breaks out above it. The MINT rule, flight values, and
 * manufacturer label form one accent. */
async function renderU01(ctx     , rd              , environment                       , appearance                ) {
  // Missing appearance keeps cards already in saved queues byte-compatible.
  // New creator layouts mirror the contents only within the existing 460px
  // scorebug footprint; the photo pixels and flight glyph order never flip.
  const discSide = appearance?.discSide ?? 'right';
  const cardX = 48, cardW = 460, cardY = 700, cardH = 360;
  const align                   = discSide === 'left' ? 'right' : 'left';
  const accent = appearance?.accentColor ?? MINT;
  const highlightTarget = appearance?.highlightTarget ?? 'digits';

  // Hero breaks out above the card.
  const d = 380;
  await drawPhotoCircle(environment, ctx, rd.photoSrc, discSide === 'left' ? 246 : 310, 600, d, accent);

  // Scorebug block: dark protection behind type only.
  ctx.fillStyle = NIGHT92;
  ctx.fillRect(cardX, cardY, cardW, cardH);
  ctx.fillStyle = accent;
  ctx.fillRect(discSide === 'left' ? cardX + cardW - 4 : cardX, cardY, 4, cardH);

  const nameX = align === 'right' ? cardX + cardW - 28 : cardX + 28;
  drawPresetName(ctx, rd.moldName, nameX, cardY + 120, cardW - 56, 96, align);

  const nums = flightTiles(rd);
  const supportMaxWidth = cardW - 56;
  const tilesY = cardY + 150;
  drawU01FlightValues(ctx, nums, nameX, tilesY, align, highlightTarget, accent);

  let detailsY = tilesY + 104;
  if (rd.manufacturer) {
    const manufacturer = rd.manufacturer.toUpperCase();
    ctx.fillStyle = accent;
    fitFont(ctx, manufacturer, supportMaxWidth, 600, 28);
    // fitFont bottoms out at its last loop size; Canvas's maxWidth keeps a
    // long catalog value inside U01's text column when that size is still wide.
    ctx.textAlign = align;
    ctx.fillText(manufacturer, nameX, detailsY, supportMaxWidth);
    detailsY += 46;
  }

  const pw = plasticWeightLine(rd);
  if (pw) {
    ctx.fillStyle = accent;
    ctx.font = `500 26px ${FONT_STACK}`;
    ctx.textAlign = align;
    ctx.fillText(pw, nameX, detailsY, supportMaxWidth);
  }
  ctx.textAlign = 'left';
}
presetRenderers.u01 = renderU01;

/** U02 Stacked Poster (VALORANT Game Changers, corner card).
 * Card footprint: x 48-508, y ~480-1210. Hero owns the top of the card;
 * mold name, manufacturer, and flight numbers form the fixed reading order.
 * Plastic and weight are optional supporting detail directly below the tiles. */
async function renderU02(ctx     , rd              , environment                       ) {
  const cardX = 48, cardW = 460;

  // Hero: top of the card, full card width.
  const d = 400;
  await drawPhotoCircle(environment, ctx, rd.photoSrc, cardX + cardW / 2, 680, d);

  // Name band: dark with the same mint accent as the photo rim. The
  // manufacturer sits directly under the name without competing with it.
  const bandY = 830, bandH = 180;
  ctx.fillStyle = NIGHT92;
  ctx.fillRect(cardX, bandY, cardW, bandH);
  ctx.fillStyle = MINT;
  ctx.fillRect(cardX, bandY, cardW, 4);

  const nameX = cardX + 28;
  drawPresetName(ctx, rd.moldName, nameX, bandY + 98, cardW - 56, 100);
  if (rd.manufacturer) {
    ctx.fillStyle = 'rgba(143,227,174,0.78)';
    ctx.font = `600 28px ${FONT_STACK}`;
    ctx.fillText(rd.manufacturer.toUpperCase(), nameX, bandY + 146);
  }

  // Flight numbers are primary: they always occupy the first row below identity.
  const nums = flightTiles(rd);
  const tilesY = 1024;
  drawTilesRow(ctx, nums, nameX, tilesY, 68, 12, 40, 'left', '#38413e', MINT);

  // Optional plastic/weight follows the tiles and never reserves an empty row.
  const pw = plasticWeightLine(rd);
  if (pw) {
    ctx.fillStyle = 'rgba(143,227,174,0.78)';
    ctx.font = `500 30px ${FONT_STACK}`;
    ctx.fillText(pw, nameX, tilesY + 108);
  }
}
presetRenderers.u02 = renderU02;

/** U3 Compare uses four explicit addresses. The inherited u03 address is the
 * original/front-left alternative, never an acceptance decision. Photo pixels
 * and glyphs keep their orientation when composition positions mirror. */
const U3_COMPARE = ['u03', 'u03-front', 'u03-behind', 'u03-front-mirror', 'u03-behind-mirror'];
export async function cardFrameSnapshot(disc              , preset            , environment                       ) {
  const facts = await resolveCardDisc(environment, disc);
  const rd = Object.freeze({...facts,flights:facts.flights ? Object.freeze([...facts.flights]) : null});
  if (!U3_COMPARE.includes(preset) && preset !== 'u04') throw Error('Layer snapshot is scoped to U3/U4');
  const accent = '#c8f23d', mirrored = preset.endsWith('-mirror');
  const mirrorX = (x        ) => mirrored ? 584 - x : x;
  let image      = null;
  if (rd.photoSrc) {
    try { image = await environment.loadImage(rd.photoSrc); }
    catch (error) { if (environment.strictPhoto) throw error; }
  }
  const photoSize = 368;
  const photo = { id: 'disc-photo', identity: JSON.stringify([rd.photoSrc, accent, photoSize]), width: photoSize, height: photoSize,
    x: mirrorX(preset === 'u04' ? 278 : 352) - photoSize / 2, y: (preset === 'u04' ? 1038 : 810) - photoSize / 2,
    draw(ctx     ) {
      const r = 180, cx = 184, cy = 184;
      ctx.save(); ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2); ctx.clip();
      if (image) { const scale = Math.max(360/image.width,360/image.height), w=image.width*scale,h=image.height*scale;ctx.drawImage(image,cx-w/2,cy-h/2,w,h); }
      else { ctx.fillStyle='#1c2a24';ctx.fillRect(4,4,360,360); }
      ctx.restore();ctx.strokeStyle=accent;ctx.lineWidth=7;ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.stroke();
    } };
  const surface = { id: 'card-surface', identity: JSON.stringify([preset === 'u04' ? 'kinetic-v2' : 'spine-v2',mirrored]), draw(ctx     ) {
    if (preset === 'u04') {
      const g=ctx.createLinearGradient(0,530,0,1170);g.addColorStop(0,'rgba(24,24,24,0)');g.addColorStop(.16,'rgba(24,24,24,.88)');g.addColorStop(.80,'rgba(24,24,24,.88)');g.addColorStop(1,'rgba(24,24,24,0)');ctx.fillStyle=g;ctx.fillRect(48,530,460,640);
    } else {ctx.fillStyle=NIGHT94;ctx.fillRect(mirrored?326:48,570,210,650);ctx.fillStyle=accent;ctx.fillRect(mirrored?326:255,570,3,650);}
  } };
  const text = { id: 'card-label', identity: JSON.stringify([preset === 'u04'?'kinetic-v2':'spine-v2',mirrored,rd.moldName,preset === 'u04'?rd.manufacturer:'',rd.flights,accent]), draw(ctx     ) {
    if(preset === 'u04') {
      ctx.textAlign='center';ctx.fillStyle=accent;fitFont(ctx,rd.manufacturer.toUpperCase(),400,600,26);ctx.fillText(rd.manufacturer.toUpperCase(),278,622);
      drawPresetName(ctx,rd.moldName,278,728,410,112,'center');
      drawTilesRow(ctx,flightTiles(rd),278,770,72,10,44,'center',accent,contrastInk(accent),true);
    } else {
      const cx=mirrorX(124);ctx.save();ctx.translate(cx,744);ctx.rotate(-Math.PI/2);ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle=INK;fitFont(ctx,rd.moldName.toUpperCase(),286,800,76,DISPLAY);ctx.fillText(rd.moldName.toUpperCase(),0,0);ctx.restore();
      ctx.textBaseline='alphabetic';ctx.font=`600 42px ${FONT_STACK}`;ctx.textAlign='center';
      for(const [i,value] of flightTiles(rd).entries()){const y=920+i*72;ctx.fillStyle=accent;ctx.fillRect(mirrorX(140)-32,y,64,64);ctx.fillStyle=contrastInk(accent);fitFont(ctx,value,52,600,42);ctx.fillText(value,mirrorX(140),y+47);}
    }
  } };
  const layers = preset === 'u04' || !preset.includes('behind') ? [surface,text,photo] : [photo,surface,text];
  return Object.freeze({ schema:'discstudio-frame-scene@1',width:1080,height:1920,preset,comparison:U3_COMPARE.includes(preset)?'Compare':undefined,layers:Object.freeze(layers.map(layer=>Object.freeze(layer))) });
}

for (const id of [...U3_COMPARE, 'u04']) presetRenderers[id] = async (ctx, rd, environment) => { const disc = { mold: '', depiction: rd.photoSrc ? {kind:'photo',src:rd.photoSrc} : {kind:'none'}, plastic:rd.plastic, weight:rd.weight, renderer:rd }       ; const scene=await cardFrameSnapshot(disc,id              ,environment); if(!environment.createCanvas) throw Error('Canvas adapter required');(environment.frameRenderer ?? createFrameRenderer({createCanvas:environment.createCanvas})).seek(ctx,scene,0); };

/** U05 Glass Stat Drawer (Ultra LoL HUD, corner card).
 * Card footprint: x 48-508, y ~450-1120. A small dark-tinted drawer in the
 * safe left; the hero overlaps it by a third. Dark tint keeps type legible
 * on bright footage (no backdrop blur in a static PNG). Glass highlight
 * line is the one motif. */
async function renderU05(ctx     , rd              , environment                       ) {
  const d = 380;
  await drawPhotoCircle(environment, ctx, rd.photoSrc, 278, 640, d);

  const gx = 48, gw = 460, gy = 800, gh = 320;
  ctx.fillStyle = 'rgba(10,14,12,0.62)';
  roundRect(ctx, gx, gy, gw, gh, 24);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.28)';
  ctx.lineWidth = 2;
  roundRect(ctx, gx, gy, gw, gh, 24);
  ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,0.10)';
  ctx.beginPath();
  ctx.moveTo(gx + 24, gy + 3);
  ctx.lineTo(gx + gw - 24, gy + 3);
  ctx.stroke();

  const nameX = gx + 36;
  drawPresetName(ctx, rd.moldName, nameX, gy + 108, gw - 72, 92);

  const nums = flightTiles(rd);
  const pw = plasticWeightLine(rd);
  let y = gy + 200;
  if (pw) {
    ctx.fillStyle = MINT;
    ctx.font = `500 30px ${FONT_STACK}`;
    ctx.fillText(pw, nameX, y);
    y += 46;
  }
  drawTilesRow(ctx, nums, nameX, y, 64, 10, 38);
}
presetRenderers.u05 = renderU05;

/* ------------------------------------------------------------------
 * BREAKOUT PRESETS (horizontal-native, 16:9) — from
 * Spotlight_Card_Visual_Research. Hero-led overlays: the disc escapes
 * the rail while the type stays defended. Law 3 throughout: scrims are
 * gradients that fade where the text ends, never boxes.
 * ------------------------------------------------------------------ */

const HW = 1920, HH = 1080;
const NIGHT = (a        ) => `rgba(5,7,6,${a})`;

/** Hero disc: CircleFit photo with optional tilt, rim, and macro zoom (B05 coin). */
async function drawHeroDisc(environment                       , ctx     , src               , cx        , cy        , d        ,
  opts                                                                                                          = {}) {
  const r = d / 2;
  ctx.save();
  ctx.translate(cx, cy);
  if (opts.tiltDeg) ctx.rotate((opts.tiltDeg * Math.PI) / 180);
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.clip();
  let drew = false;
  if (src) {
    try {
      const img = await environment.loadImage(src);
      if (opts.macro) {
        // Dual-scale: zoom into a sub-rect of the same photo.
        const { zoom, fx, fy } = opts.macro;
        const s = Math.min(img.width, img.height) / zoom;
        const sx = Math.min(Math.max(fx * img.width - s / 2, 0), img.width - s);
        const sy = Math.min(Math.max(fy * img.height - s / 2, 0), img.height - s);
        ctx.drawImage(img, sx, sy, s, s, -r, -r, d, d);
      } else {
        const scale = Math.max(d / img.width, d / img.height);
        const w = img.width * scale, h = img.height * scale;
        ctx.drawImage(img, -w / 2, -h / 2, w, h);
      }
      drew = true;
    } catch (error) {
      if (environment.strictPhoto) throw new Error(`Prepared photo could not be decoded for export: ${String(error)}`);
      drew = false;
    }
  }
  if (!drew) {
    ctx.fillStyle = '#1d2b25';
    ctx.fillRect(-r, -r, d, d);
    ctx.strokeStyle = 'rgba(255,255,255,0.25)';
    ctx.lineWidth = Math.max(4, d * 0.012);
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.62, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
  if (opts.rim) {
    ctx.save();
    ctx.translate(cx, cy);
    if (opts.tiltDeg) ctx.rotate((opts.tiltDeg * Math.PI) / 180);
    ctx.strokeStyle = opts.rim;
    ctx.lineWidth = opts.rimWidth ?? 8;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}

/** Law 3: horizontal scrim, dark where the type sits, fading where it ends. */
function scrimH(ctx     , x        , y        , w        , h        , flip = false) {
  const g = flip ? ctx.createLinearGradient(x + w, 0, x, 0) : ctx.createLinearGradient(x, 0, x + w, 0);
  g.addColorStop(0, NIGHT(0.96));
  g.addColorStop(0.75, NIGHT(0.72));
  g.addColorStop(1, NIGHT(0));
  ctx.fillStyle = g;
  ctx.fillRect(x, y, w, h);
}

/** Law 3: vertical scrim, dark at the bottom, fading upward. */
function scrimV(ctx     , x        , y        , w        , h        ) {
  const g = ctx.createLinearGradient(0, y + h, 0, y);
  g.addColorStop(0, NIGHT(0.98));
  g.addColorStop(0.55, NIGHT(0.72));
  g.addColorStop(1, NIGHT(0));
  ctx.fillStyle = g;
  ctx.fillRect(x, y, w, h);
}

/** Quiet plastic/weight line under the name. */
function drawQuietLine(ctx     , text        , x        , y        , px = 40) {
  ctx.font = `500 ${px}px ${FONT_STACK}`;
  ctx.fillStyle = 'rgba(255,255,255,0.78)';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
  ctx.fillText(text, x, y);
}

/** B01 Pop Color Eject (VALORANT Game Changers) — CORNER CARD.
 * Small rail in the bottom-left corner. The disc breaks out: tilted 12 deg,
 * crossing the rail's top and right edges. One loud color (acid), used once
 * as the rail's left edge. ASYMMETRY · MAXIMAL HERO · ONE LOUD COLOR */
async function renderB01(ctx     , rd              , environment                       ) {
  // Card footprint: bottom-left, 620x380.
  const cx0 = 48, cy0 = HH - 48 - 380, cw = 620, ch = 380;
  // Defended type zone: scrim behind the card only, fading right.
  scrimH(ctx, cx0, cy0, cw + 140, ch);
  ctx.fillStyle = ACID;
  ctx.fillRect(cx0, cy0, 6, ch);
  // Hero breaks out: 12-degree tilt, crossing the card's top-right corner.
  await drawHeroDisc(environment, ctx, rd.photoSrc, cx0 + cw + 40, cy0 - 60, 420,
    { tiltDeg: 12, rim: 'rgba(255,255,255,0.9)', rimWidth: 8 });
  // Type stays inside the card.
  const nx = cx0 + 36;
  drawPresetName(ctx, rd.moldName, nx, cy0 + 132, cw - 72, 104);
  const pw = plasticWeightLine(rd);
  if (pw) drawQuietLine(ctx, pw, nx, cy0 + 182, 34);
  drawTilesRow(ctx, flightTiles(rd), nx, cy0 + 212, 62, 14, 36);
}
presetRenderers.b01 = renderB01;

/** B02 Smoky Fade Slab (2024 Topps) — CORNER CARD.
 * Compact slab in the bottom-left. The disc's rim tucks under the name's
 * trailing letter: three depth layers (scrim, disc, name over rim).
 * DISCLEGIBILITY · THREE DEPTH LAYERS · GRADIENT NOT BOX */
async function renderB02(ctx     , rd              , environment                       ) {
  // Card footprint: bottom-left, 600x360.
  const cx0 = 48, cy0 = HH - 48 - 360, cw = 600, ch = 360;
  // Layer 1: smoky gradient slab, card-sized, fading up and right.
  scrimV(ctx, cx0 - 20, cy0 - 60, cw + 160, ch + 60);
  const nx = cx0 + 36;
  // Layer 2: hero at the card's top-right; its left rim tucks under the
  // name's trailing letter (name drawn after = on top).
  ctx.font = `800 120px ${DISPLAY}`;
  const nameW = Math.min(ctx.measureText(rd.moldName.toUpperCase()).width, cw - 200);
  const d = 380;
  const dcx = nx + nameW + 130; // left rim lands ~60px under the name's end
  await drawHeroDisc(environment, ctx, rd.photoSrc, dcx, cy0 + 30, d,
    { rim: 'rgba(255,255,255,0.9)', rimWidth: 8 });
  // Layer 3: name rides over the rim; stats stay defended below.
  drawPresetName(ctx, rd.moldName, nx, cy0 + 118, cw - 72, 120);
  const pw = plasticWeightLine(rd);
  if (pw) drawQuietLine(ctx, pw, nx, cy0 + 168, 34);
  drawTilesRow(ctx, flightTiles(rd), nx, cy0 + 198, 62, 14, 36);
}
presetRenderers.b02 = renderB02;

/** B03 Trading Plate Break (NFL on Fox) — CORNER CARD.
 * Small rigid plate in the bottom-left. The hero interrupts the plate's
 * top-right corner; the acid pin marks that single rule-break as
 * intentional. PLATE DISCIPLINE · ONE RULE-BREAK */
async function renderB03(ctx     , rd              , environment                       ) {
  // Card footprint: bottom-left plate, 580x340.
  const px = 48, py = HH - 48 - 340, pw = 580, ph = 340;
  ctx.fillStyle = 'rgba(5,7,6,0.82)';
  ctx.fillRect(px, py, pw, ph);
  ctx.strokeStyle = 'rgba(255,255,255,0.55)';
  ctx.lineWidth = 2;
  ctx.strokeRect(px, py, pw, ph);
  // The hero breaks the plate's top-right corner.
  const d = 340;
  await drawHeroDisc(environment, ctx, rd.photoSrc, px + pw, py, d,
    { rim: 'rgba(255,255,255,0.9)', rimWidth: 8 });
  // Acid pin: the rule-break, made deliberate.
  ctx.save();
  ctx.translate(px + pw, py);
  ctx.rotate(Math.PI / 4);
  ctx.fillStyle = ACID;
  ctx.fillRect(-8, -8, 16, 16);
  ctx.restore();
  // Type stays disciplined inside the plate, clear of the disc.
  const nx = px + 36;
  drawPresetName(ctx, rd.moldName, nx, py + 128, pw - 220, 100);
  const q = plasticWeightLine(rd);
  if (q) drawQuietLine(ctx, q, nx, py + 178, 34);
  drawTilesRow(ctx, flightTiles(rd), nx, py + 208, 62, 14, 36);
}
presetRenderers.b03 = renderB03;

/** B04 Flight-Path Arc (Trollbäck NFL GameDay) — CORNER CARD.
 * Small card in the bottom-left. One acid S-curve lives inside the card;
 * the disc sits on the arc's peak, breaking out slightly above the card.
 * Name and stats attach like stations. The arc is the single motif.
 * SPORT-AUTHENTIC MOTIF · EXIT SPACE · EDITORIAL DRAMA */
async function renderB04(ctx     , rd              , environment                       ) {
  // Card footprint: bottom-left, 620x380.
  const cx0 = 48, cy0 = HH - 48 - 380, cw = 620, ch = 380;
  // Defended type zone: scrim behind the card only.
  scrimH(ctx, cx0, cy0, cw + 120, ch);
  // The motif: one small S-curve with a peak, inside the card.
  const ax0 = cx0 + 40, ay0 = cy0 + ch - 60;      // arc start, bottom-left
  const peakX = cx0 + cw * 0.55, peakY = cy0 + 90; // arc peak
  const ax1 = cx0 + cw - 30, ay1 = cy0 + ch - 100; // arc end, bottom-right
  ctx.strokeStyle = ACID;
  ctx.lineWidth = 7;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(ax0, ay0);
  ctx.quadraticCurveTo(cx0 + cw * 0.30, ay0 + 10, peakX, peakY);
  ctx.quadraticCurveTo(cx0 + cw * 0.78, peakY + 30, ax1, ay1);
  ctx.stroke();
  // The disc sits on the peak like a ball on a hill, breaking out above.
  const d = 280;
  await drawHeroDisc(environment, ctx, rd.photoSrc, peakX, peakY - d / 2 + 18, d,
    { rim: 'rgba(255,255,255,0.9)', rimWidth: 7 });
  // Name station: bottom-left. Stats station: bottom-right.
  const nx = cx0 + 36;
  drawPresetName(ctx, rd.moldName, nx, cy0 + ch - 108, cw * 0.52, 88);
  const nums = flightTiles(rd);
  const total = nums.length * 62 + (nums.length - 1) * 14;
  drawTilesRow(ctx, nums, cx0 + cw - 36 - total, cy0 + ch - 96, 62, 14, 36);
}
presetRenderers.b04 = renderB04;

/** B05 Stamp Macro + Hero (Topps 2020-2025) — CORNER CARD.
 * Small card in the bottom-left. The name reads HORIZONTALLY across the
 * top (the vertical-spine bug is fixed). The hero sits right, breaking
 * out; a small acid-rimmed macro coin shows the same subject at 2.6x.
 * DUAL-SCALE IMAGE · HORIZONTAL NAME · PRODUCT DETAIL */
async function renderB05(ctx     , rd              , environment                       ) {
  // Card footprint: bottom-left, 600x380.
  const cx0 = 48, cy0 = HH - 48 - 380, cw = 600, ch = 380;
  scrimH(ctx, cx0, cy0, cw + 140, ch);
  // Name: horizontal, top of card. Never vertical, never clipped.
  const nx = cx0 + 36;
  drawPresetName(ctx, rd.moldName, nx, cy0 + 108, cw - 220, 96);
  // Hero: right side, breaking out top and right.
  const d = 340;
  await drawHeroDisc(environment, ctx, rd.photoSrc, cx0 + cw - 80, cy0 + 130, d,
    { rim: 'rgba(255,255,255,0.9)', rimWidth: 8 });
  // Macro coin: same subject at 2.6x, overlapping the card's lower-left.
  await drawHeroDisc(environment, ctx, rd.photoSrc, cx0 + 120, cy0 + ch - 90, 150,
    { rim: ACID, rimWidth: 5, macro: { zoom: 2.6, fx: 0.62, fy: 0.38 } });
  // Stats: bottom, clear of the coin.
  const sx = cx0 + 210;
  const q = plasticWeightLine(rd);
  if (q) drawQuietLine(ctx, q, sx, cy0 + ch - 118, 32);
  drawTilesRow(ctx, flightTiles(rd), sx, cy0 + ch - 88, 58, 12, 34);
}
presetRenderers.b05 = renderB05;

/** Draw one existing SpotlightCard layout onto a supplied Canvas2D context. */
export async function drawCard(
  context     ,
  disc              ,
  orientation                 ,
  preset                        ,
  environment                       ,
  u01Appearance                ,
)                {
  if (orientation !== 'horizontal' && orientation !== 'vertical') {
    throw new Error(`orientation must be 'horizontal' or 'vertical', got ${String(orientation)}`);
  }
  if (preset && (U3_COMPARE.includes(preset) || preset === 'u04')) {
    if (orientation !== 'vertical') throw Error(`preset ${preset} is vertical-native; use orientation 'vertical'`);
    if (!environment.createCanvas) throw Error('U3/U4 frame renderer requires a Canvas adapter');
    const renderer = environment.frameRenderer ?? createFrameRenderer({ createCanvas: environment.createCanvas });
    const scene = await cardFrameSnapshot(disc,preset,environment);
    environment.onFrame?.(renderer.seek(context,scene,0));
    if (!environment.onFrame) renderer.seek(context,scene,0);
    return;
  }
  const rd = await resolveCardDisc(environment, disc);
  if (preset) {
    const fn = presetRenderers[preset];
    if (!fn) throw new Error(`unknown card preset: ${preset}`);
    if (preset[0] === 'u' && orientation !== 'vertical') {
      throw new Error(`preset ${preset} is vertical-native; use orientation 'vertical'`);
    }
    if (preset[0] === 'b' && orientation !== 'horizontal') {
      throw new Error(`preset ${preset} is horizontal-native; use orientation 'horizontal'`);
    }
    const appearance = preset === 'u01' && u01Appearance ? validateU01Appearance(u01Appearance) : undefined;
    await fn(context, rd, environment, appearance);
  } else if (orientation === 'horizontal') await drawHorizontal(environment, context, rd);
  else await drawVertical(environment, context, rd);
}
