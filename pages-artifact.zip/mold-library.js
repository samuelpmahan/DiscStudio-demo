// Mold library: lite-first with prefix trie for instant search.
// Lite loads id+manufacturer+mold (<50ms). Full details lazy on selection.

import { catalogLite } from './catalog-lite.js?v=1b442cfa0e9048b5';

                                                                          

// Prefix trie: each node maps char -> child, plus list of mold ids at this prefix.
                                                                   

function buildTrie(molds            )           {
  const root           = { children: new Map(), ids: [] };
  for (const { id, mold, manufacturer } of molds) {
    // Index by mold name and by "manufacturer mold" for "discraft buzzz" queries.
    for (const key of [mold.toLowerCase(), `${manufacturer} ${mold}`.toLowerCase()]) {
      let node = root;
      for (const ch of key) {
        if (!node.children.has(ch)) node.children.set(ch, { children: new Map(), ids: [] });
        node = node.children.get(ch) ;
        if (!node.ids.includes(id)) node.ids.push(id);
      }
    }
  }
  return root;
}

const trie = buildTrie(catalogLite);
const byId = new Map(catalogLite.map(m => [m.id, m]));

/** Prefix search via trie. O(k) where k = query length. */
export function searchMolds(query        , limit = 20)             {
  const q = query.toLowerCase().trim();
  if (!q) return catalogLite.slice(0, limit);
  let node = trie;
  for (const ch of q) {
    const next = node.children.get(ch);
    if (!next) return [];
    node = next;
  }
  return node.ids.slice(0, limit).map(id => byId.get(id) ).filter(Boolean);
}

/** Get full mold details (lazy: imports full catalog on first call). */
let fullCatalog               = null;
export async function getMoldDetails(id        ) {
  if (!fullCatalog) {
    const { catalog } = await import('./catalog.js?v=1b442cfa0e9048b5');
    fullCatalog = catalog;
  }
  return fullCatalog.find((m     ) => m.id === id) ?? null;
}

export { catalogLite };
