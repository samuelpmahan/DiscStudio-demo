/** One centered cover crop for preview and combined scene export. */
export function coverSourceRect(sourceWidth, sourceHeight, frameWidth, frameHeight) {
  if (![sourceWidth, sourceHeight, frameWidth, frameHeight].every(value => Number.isFinite(value) && value > 0)) throw Error('Background and frame dimensions must be positive');
  const frameRatio = frameWidth / frameHeight, sourceRatio = sourceWidth / sourceHeight;
  if (sourceRatio > frameRatio) {
    const width = sourceHeight * frameRatio;
    return { x: (sourceWidth - width) / 2, y: 0, width, height: sourceHeight };
  }
  const height = sourceWidth / frameRatio;
  return { x: 0, y: (sourceHeight - height) / 2, width: sourceWidth, height };
}

export function drawBackgroundCover(context, image, width, height) {
  const sourceWidth = image.naturalWidth || image.width, sourceHeight = image.naturalHeight || image.height;
  const crop = coverSourceRect(sourceWidth, sourceHeight, width, height);
  context.drawImage(image, crop.x, crop.y, crop.width, crop.height, 0, 0, width, height);
  return crop;
}
