import { storageKey } from './persistence.js?v=9178cd6d18d3bdc5';

/** The original single-shelf archive is retained verbatim for future recovery. */
export const legacyStorageKey = storageKey;
export const sessionKeyPrefix = 'discstudio.pxc.session.v1.';
/** Points to the current durable Bag archive without moving or deleting older sessions. */
export const activeSessionKey = 'discstudio.pxc.active-session.v1';
export const cardSetupStorageKey = 'discstudio.card-setup.v1';

                                                                                 
                                                                                          

                                                                        
                                                                                                                       

function errorOf(error         )        { return error instanceof Error ? error : Error(String(error)); }

/**
 * Every launch gets its own durable slot. We deliberately do not copy or
 * rewrite the legacy shelf: a later release can discover both that untouched
 * archive and every prefixed session key without a shared merge point.
 */
export function createFreshSession(options                                                    = {})                     {
  try {
    const id = options.sessionId ?? options.randomUUID?.() ?? globalThis.crypto?.randomUUID();
    if (typeof id !== 'string' || !/^[a-zA-Z0-9-]{16,}$/.test(id)) throw Error('Secure session id unavailable.');
    return { ok: true, session: Object.freeze({ id, currentKey: `${sessionKeyPrefix}${id}` }) };
  } catch (error) { return { ok: false, error: errorOf(error) }; }
}

/** Read-only discovery for a future archive browser; never changes old bytes. */
export function discoverSessionKeys(storage            )                    {
  const keys           = [];
  for (let index = 0; index < storage.length; index++) {
    const key = storage.key(index);
    if (key && (key === legacyStorageKey || key.startsWith(sessionKeyPrefix))) keys.push(key);
  }
  return Object.freeze(keys.sort());
}


                                                                                                                                                          

/** Removes only DiscStudio's durable archives, never unrelated local storage. */
export function clearLocalData(storage                  )                       {
  let matching          ;
  try {
    matching = [];
    for (let index = 0; index < storage.length; index++) {
      const key = storage.key(index);
      if (key === legacyStorageKey || key === activeSessionKey || key === cardSetupStorageKey || key?.startsWith(sessionKeyPrefix) || key?.startsWith('tick-part-checklist:discstudio-creator-review:')) matching.push(key);
    }
  } catch (error) { return { ok: false, removed: Object.freeze([]), error: errorOf(error) }; }

  const removed           = [];
  try {
    for (const key of matching) {
      storage.removeItem(key);
      removed.push(key);
    }
    return { ok: true, removed: Object.freeze(removed) };
  } catch (error) { return { ok: false, removed: Object.freeze(removed), error: errorOf(error) }; }
}
