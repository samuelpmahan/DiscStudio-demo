/** Three supplied photos with the pictured mold bound to the catalog selection. */
export const sampleDiscs = [
  { id: 'discraft--buzzz-ss', manufacturer: 'Discraft', mold: 'Buzzz SS', photo: './sample-discs/buzzz-ss.jpg', filename: 'buzzz-ss.jpg', plastic: 'Z FLX' },
  { id: 'mvp--servo', manufacturer: 'MVP', mold: 'Servo', photo: './sample-discs/servo.jpg', filename: 'servo.jpg', plastic: 'Neutron' },
  { id: 'latitude-64--anchor', manufacturer: 'Latitude 64', mold: 'Anchor', photo: './sample-discs/anchor.jpg', filename: 'anchor.jpg', plastic: 'Opto' },
]         ;
