import { openExperience } from './persistent-experience.js?v=1b442cfa0e9048b5';
import { mountExperiencePageShare } from './experience-page-share.js?v=1b442cfa0e9048b5';
import { clearLocalData } from './session-storage.js?v=1b442cfa0e9048b5';

async function main() {
  const $ = (id        ) => document.getElementById(id) ;
  const dialog = $('clear-local-data')                     ;
  const error = $('clear-local-data-error');
  const confirm = $('clear-local-data-confirm')                     ;
  $('clear-local-data-button').addEventListener('click', () => { error.textContent = ''; dialog.showModal(); });
  $('clear-local-data-cancel').addEventListener('click', () => dialog.close());
  confirm.addEventListener('click', () => {
    error.textContent = ''; confirm.disabled = true;
    try {
      const result = clearLocalData(window.localStorage);
      if (result.ok) location.reload();
      else { confirm.disabled = false; error.textContent = result.removed.length ? 'Some local DiscStudio data was removed, but the rest could not be cleared. Your current session remains open.' : 'Local DiscStudio data could not be cleared. Your current session remains open.'; }
    } catch {
      confirm.disabled = false;
      error.textContent = 'Local DiscStudio data could not be accessed. Your current session remains open.';
    }
  });
  const experience = await openExperience(window.localStorage, () => {});
  await mountExperiencePageShare(experience);
}
main();
