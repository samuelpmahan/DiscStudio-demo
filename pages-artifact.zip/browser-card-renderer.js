// Browser Canvas2D adapter for the shared SpotlightCard draw routines.
import { CARD_SIZE, drawCard,                                                          } from './card-renderer-core.js?v=1b442cfa0e9048b5';
import { getMoldDetails } from './mold-library.js?v=1b442cfa0e9048b5';
import { identityTransform } from './transform-geometry.mjs?v=1b442cfa0e9048b5';
                                                            
export { CARD_SIZE };
                                            

function browserImage(source        )                            {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.decoding = 'async';
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('Prepared photo could not be read for this card.'));
    image.src = source;
  });
}

function canvasBlob(canvas                   )                {
  return new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('Browser could not encode the card PNG.')), 'image/png'));
}

export async function renderCardBlob(disc              , orientation                 , preset             )                {
  const { w, h } = CARD_SIZE[orientation];
  const canvas = document.createElement('canvas');
  canvas.width = w; canvas.height = h;
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Canvas2D is unavailable in this browser.');
  await drawCard(context, disc, orientation, preset, { loadImage: browserImage, getMoldDetails, strictPhoto: true });
  return canvasBlob(canvas);
}

export async function renderCardPreview(disc              , orientation                 , preset             )                  {
  return URL.createObjectURL(await renderCardBlob(disc, orientation, preset));
}

export async function renderPlacedCardBlob(disc              , orientation                 , preset             , placement                )                {
  const source = await renderCardBlob(disc, orientation, preset);
  const transform = placement ?? identityTransform;
  if (transform.scale === 1 && transform.dx === 0 && transform.dy === 0) return source;
  const url = URL.createObjectURL(source);
  let image                  ;
  try { image = await browserImage(url); }
  finally { URL.revokeObjectURL(url); }
  const { w, h } = CARD_SIZE[orientation], canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
  const context = canvas.getContext('2d'); if (!context) throw new Error('Canvas2D is unavailable in this browser.');
  context.translate(w / 2 + transform.dx * w, h / 2 + transform.dy * h); context.scale(transform.scale, transform.scale);
  context.drawImage(image, -w / 2, -h / 2, w, h);
  return canvasBlob(canvas);
}
