// Browser Canvas2D adapter for the shared SpotlightCard draw routines.
import { createFrameRenderer, imageLayer } from './frame-seek.mjs?v=ec54266e9adf8ea0';
import { CARD_SIZE, drawCard,                                                          } from './card-renderer-core.js?v=ec54266e9adf8ea0';
import { getMoldDetails } from './mold-library.js?v=ec54266e9adf8ea0';
import { identityTransform } from './transform-geometry.mjs?v=ec54266e9adf8ea0';
                                                                            
import { alphaBounds, cardRasterIdentity, createStickerSizer, stickerOrigin } from './sticker-raster.mjs?v=ec54266e9adf8ea0';
export { CARD_SIZE };
                                            

function decodeBrowserImage(source        )                            {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.decoding = 'async';
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('Prepared photo could not be read for this card.'));
    image.src = source;
  });
}

const createBrowserCanvas = (width       ,height       ) => { const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;return canvas; };
export const browserFrames = createFrameRenderer({createCanvas:createBrowserCanvas});
export const browserStickerSizer = createStickerSizer({createCanvas:createBrowserCanvas,frameRenderer:browserFrames});
export function sizeBrowserSticker(image                   , nativeWidth        , nativeHeight        , nativeBounds                   , identity        , scale        ) {
  return browserStickerSizer.size({image,nativeWidth,nativeHeight,nativeBounds,identity,scale});
}
const photos = new Map                                  ();
function browserImage(source       ) { if(!photos.has(source)){photos.set(source,decodeBrowserImage(source));if(photos.size>8)photos.delete(photos.keys().next().value );}return photos.get(source) ; }

function canvasBlob(canvas                   )                {
  return new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('Browser could not encode the card PNG.')), 'image/png'));
}

export async function renderCardBlob(disc              , orientation                 , preset             , appearance                 )                {
  const { w, h } = CARD_SIZE[orientation];
  const canvas = document.createElement('canvas');
  canvas.width = w; canvas.height = h;
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Canvas2D is unavailable in this browser.');
  await drawCard(context, disc, orientation, preset, { loadImage: browserImage, getMoldDetails, strictPhoto: true,createCanvas:createBrowserCanvas,frameRenderer:browserFrames }, appearance);
  return canvasBlob(canvas);
}

export async function renderCardPreview(disc              , orientation                 , preset             , appearance                 )                  {
  return URL.createObjectURL(await renderCardBlob(disc, orientation, preset, appearance));
}

export async function renderPlacedCardBlob(disc              , orientation                 , preset             , placement                , appearance                 )                {
  const transform = placement ?? identityTransform;
  if (transform.scale === 1 && transform.dx === 0 && transform.dy === 0) return renderCardBlob(disc, orientation, preset, appearance);
  const sticker = await renderStickerCardRaster(disc,orientation,preset,transform.scale,appearance);
  const { w, h } = CARD_SIZE[orientation], canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
  const context = canvas.getContext('2d'); if (!context) throw new Error('Canvas2D is unavailable in this browser.');
  const origin=stickerOrigin({width:w,height:h,nativeBounds:sticker.nativeBounds,placement:transform,sticker});
  browserFrames.seek(context,{width:w,height:h,layers:[{...imageLayer('placement-card',sticker.identity,sticker.canvas,sticker.width,sticker.height),...origin}]},0);
  return canvasBlob(canvas);
}

export async function renderStickerCardRaster(disc              , orientation                 , preset             , scale = 1, appearance                 ) {
  const source=await renderCardBlob(disc,orientation,preset,appearance),url=URL.createObjectURL(source);
  try {
    const image=await decodeBrowserImage(url),{w,h}=CARD_SIZE[orientation],native=createBrowserCanvas(w,h),ctx=native.getContext('2d') ;
    ctx.drawImage(image,0,0);
    const bounds=alphaBounds(ctx.getImageData(0,0,w,h).data,w,h);
    return sizeBrowserSticker(image,w,h,bounds,cardRasterIdentity(disc,orientation,preset,appearance),scale);
  } finally { URL.revokeObjectURL(url); }
}
export async function renderStickerCardBlob(disc              , orientation                 , preset             , scale = 1, appearance                 )                {
  return canvasBlob((await renderStickerCardRaster(disc,orientation,preset,scale,appearance)).canvas);
}
