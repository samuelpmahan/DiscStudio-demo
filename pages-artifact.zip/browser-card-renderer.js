// Browser Canvas2D adapter for the shared SpotlightCard draw routines.
import { createFrameRenderer, imageLayer } from './frame-seek.mjs?v=f744e0e8caf2a721';
import { CARD_SIZE, drawCard,                                                          } from './card-renderer-core.js?v=f744e0e8caf2a721';
import { getMoldDetails } from './mold-library.js?v=f744e0e8caf2a721';
import { identityTransform } from './transform-geometry.mjs?v=f744e0e8caf2a721';
                                                                           
export { CARD_SIZE };
                                            

function decodeBrowserImage(source        )                            {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.decoding = 'async';
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('Prepared photo could not be read for this card.'));
    image.src = source;
  });
}

const createBrowserCanvas = (width       ,height       ) => { const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;return canvas; };
export const browserFrames = createFrameRenderer({createCanvas:createBrowserCanvas});
const photos = new Map                                  ();
function browserImage(source       ) { if(!photos.has(source)){photos.set(source,decodeBrowserImage(source));if(photos.size>8)photos.delete(photos.keys().next().value );}return photos.get(source) ; }

function canvasBlob(canvas                   )                {
  return new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('Browser could not encode the card PNG.')), 'image/png'));
}

export async function renderCardBlob(disc              , orientation                 , preset             , u01Appearance                )                {
  const { w, h } = CARD_SIZE[orientation];
  const canvas = document.createElement('canvas');
  canvas.width = w; canvas.height = h;
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Canvas2D is unavailable in this browser.');
  await drawCard(context, disc, orientation, preset, { loadImage: browserImage, getMoldDetails, strictPhoto: true,createCanvas:createBrowserCanvas,frameRenderer:browserFrames }, u01Appearance);
  return canvasBlob(canvas);
}

export async function renderCardPreview(disc              , orientation                 , preset             , u01Appearance                )                  {
  return URL.createObjectURL(await renderCardBlob(disc, orientation, preset, u01Appearance));
}

export async function renderPlacedCardBlob(disc              , orientation                 , preset             , placement                , u01Appearance                )                {
  const source = await renderCardBlob(disc, orientation, preset, u01Appearance);
  const transform = placement ?? identityTransform;
  if (transform.scale === 1 && transform.dx === 0 && transform.dy === 0) return source;
  const url = URL.createObjectURL(source);
  let image                  ;
  try { image = await browserImage(url); }
  finally { URL.revokeObjectURL(url); }
  const { w, h } = CARD_SIZE[orientation], canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
  const context = canvas.getContext('2d'); if (!context) throw new Error('Canvas2D is unavailable in this browser.');
  browserFrames.seek(context,{width:w,height:h,layers:[imageLayer('placement-card',JSON.stringify([disc,orientation,preset,u01Appearance]),image,w,h,transform)]},0);
  return canvasBlob(canvas);
}
