import { prepareExport,                                    } from './export-queue-core.js?v=28ac2b39fab85255';
import { storedZip } from './zip.js?v=28ac2b39fab85255';

const hex = (bytes             ) => [...new Uint8Array(bytes)].map(byte => byte.toString(16).padStart(2, '0')).join('');
async function sha256(bytes            )                  { return hex(await crypto.subtle.digest('SHA-256', bytes)); }
export async function exportBrowserZip(queue                       , renderCard              )                                                                               {
  const { rendered, manifest } = await prepareExport(queue, renderCard, sha256);
  const manifestText = JSON.stringify(manifest, null, 2);
  const blob = storedZip([...rendered.map(({ filename, png }) => ({ name: filename, bytes: png })), { name: 'manifest.json', bytes: new TextEncoder().encode(manifestText) }]);
  return { blob, manifest, manifestId: `sha256:${await sha256(new TextEncoder().encode(manifestText))}`, zipId: `sha256:${await sha256(new Uint8Array(await blob.arrayBuffer()))}` };
}
export function downloadUrl(url        , filename        ) {
  const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename; anchor.style.position = 'fixed'; anchor.style.left = '-10000px';
  document.body.append(anchor); anchor.click(); anchor.remove();
}
export function downloadBlob(blob      , filename        ) {
  const url = URL.createObjectURL(blob); downloadUrl(url, filename); setTimeout(() => URL.revokeObjectURL(url), 30_000);
}
