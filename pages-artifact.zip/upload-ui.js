import { prepareCirclePhoto, prepareEllipsePhoto, validateRefitSource,                  } from './photo-refit.js?v=29b3489a3ed5d6cc';
import { initialDraft, flightFields,                                                   } from './model.js?v=29b3489a3ed5d6cc';
import { plasticGuides } from './plastics.js?v=29b3489a3ed5d6cc';
import { createDiscView } from './disc-view.js?v=29b3489a3ed5d6cc';
import { recipeFromDraft, validatePaintRecipe, renderDepiction } from './paint-recipe.js?v=29b3489a3ed5d6cc';
import { cropForSourceSamples, drawRotatedCrop, normalizeCropRotation } from './crop-geometry.js?v=29b3489a3ed5d6cc';
import { composeCircleCandidateChoices, createCircleCandidateSession,                                                                    } from './circle-fit.js?v=29b3489a3ed5d6cc';
import { paintedDiscsEnabled } from './kompozition.js?v=29b3489a3ed5d6cc';
import { sampleDiscs } from './sample-discs.js?v=29b3489a3ed5d6cc';
import { createRimFitWorkerClient } from './rimfit-v3/worker-client.mjs?v=29b3489a3ed5d6cc';
import { adaptRimFitResult } from './experimental/ellipse-fit-fix/fit-adapter.mjs?v=29b3489a3ed5d6cc';
import { validateEllipseBounds } from './experimental/ellipse-fit-fix/ellipse-geometry.mjs?v=29b3489a3ed5d6cc';
export { detectDiscCircle } from './circle-fit.js?v=29b3489a3ed5d6cc';
                                                                   

                                                                                                                 

export const cropZoomNudges = [-10, -5, -3, -1, 1, 3, 5, 10]         ;
const minCropRadiusRatio = .03;
const clamp = (value        , min        , max        ) => Math.min(max, Math.max(min, value));
function validDimensions(width        , height        ) {
  if (![width, height].every(value => Number.isFinite(value) && value > 0)) throw Error('Photo dimensions must be positive.');
}

/** Selection center and ellipse radii are normalized independently to source width/height. */
export function clampCropSelection(width        , height        , crop           )            {
  validDimensions(width, height);
  const minimum = minCropRadiusRatio, rotation = normalizeCropRotation(crop?.rotation);
  const rawRadiusX = Math.max(minimum, Number.isFinite(crop?.radiusX) ? crop.radiusX : .4);
  const rawRadiusY = Math.max(minimum, Number.isFinite(crop?.radiusY) ? crop.radiusY : .4);
  // Fit the rotated ellipse itself, rather than incorrectly clipping axes to .5.
  const cos = Math.cos(rotation), sin = Math.sin(rotation);
  const halfX = Math.hypot(rawRadiusX * cos, rawRadiusY * sin), halfY = Math.hypot(rawRadiusX * sin, rawRadiusY * cos);
  const scale = Math.min(1, .5 / halfX, .5 / halfY);
  const radiusX = rawRadiusX * scale, radiusY = rawRadiusY * scale;
  const boundedHalfX = halfX * scale, boundedHalfY = halfY * scale;
  const centerX = clamp(Number.isFinite(crop?.centerX) ? crop.centerX : .5, boundedHalfX, 1 - boundedHalfX);
  const centerY = clamp(Number.isFinite(crop?.centerY) ? crop.centerY : .5, boundedHalfY, 1 - boundedHalfY);
  return { centerX, centerY, radiusX, radiusY, rotation };
}

export function cropForDetectedCircle(width        , height        , circle            )            {
  return clampCropSelection(width, height, cropForSourceSamples(width, height, circle));
}

export function resizeCrop(width        , height        , crop           , deltaPercent        )            {
  if (!cropZoomNudges.includes(deltaPercent                                 )) throw Error('Unsupported crop selection nudge.');
  const bounded = clampCropSelection(width, height, crop);
  const radiusDelta = deltaPercent / 200;
  return clampCropSelection(width, height, { ...bounded, radiusX: bounded.radiusX + radiusDelta, radiusY: bounded.radiusY + radiusDelta });
}

/** Active creator aperture: one source-pixel radius with independent orientation. */
export function clampCircleCropSelection(width        , height        , crop           )            {
  validDimensions(width, height);
  const minRadius = minCropRadiusRatio * Math.min(width, height);
  const xRadius = Number.isFinite(crop?.radiusX) ? crop.radiusX * width : NaN;
  const yRadius = Number.isFinite(crop?.radiusY) ? crop.radiusY * height : NaN;
  const radius = clamp(Math.max(Number.isFinite(xRadius) ? xRadius : 0, Number.isFinite(yRadius) ? yRadius : 0, minRadius), minRadius, Math.min(width, height) / 2);
  const centerX = clamp(Number.isFinite(crop?.centerX) ? crop.centerX * width : width / 2, radius, width - radius);
  const centerY = clamp(Number.isFinite(crop?.centerY) ? crop.centerY * height : height / 2, radius, height - radius);
  return { centerX: centerX / width, centerY: centerY / height, radiusX: radius / width, radiusY: radius / height, rotation: Number.isFinite(crop.rotation) ? crop.rotation : 0 };
}

/** Cap a manual resize at the current center, never translating the photo. */
export function resizeCircleAtFixedCenter(width        , height        , crop           , requestedRadius        )            {
  if (!Number.isFinite(requestedRadius)) throw Error('Circle resize needs a finite radius.');
  const bounded = clampCircleCropSelection(width, height, crop), centerX = bounded.centerX * width, centerY = bounded.centerY * height;
  const minRadius = minCropRadiusRatio * Math.min(width, height), maxRadius = Math.min(centerX, width - centerX, centerY, height - centerY);
  const radius = clamp(requestedRadius, minRadius, maxRadius);
  return { centerX: bounded.centerX, centerY: bounded.centerY, radiusX: radius / width, radiusY: radius / height, rotation: bounded.rotation };
}

export function resizeCircleCrop(width        , height        , crop           , deltaPercent        )            {
  if (!cropZoomNudges.includes(deltaPercent                                 )) throw Error('Unsupported crop selection nudge.');
  const bounded = clampCircleCropSelection(width, height, crop), radius = bounded.radiusX * width + Math.min(width, height) * deltaPercent / 200;
  return resizeCircleAtFixedCenter(width, height, bounded, radius);
}

/** Move the source photo beneath the fixed preview aperture. */
export function panCircleCrop(width        , height        , crop           , sourceDeltaX        , sourceDeltaY        )            {
  if (![sourceDeltaX, sourceDeltaY].every(Number.isFinite)) throw Error('Photo pan needs finite source movement.');
  const bounded = clampCircleCropSelection(width, height, crop);
  return clampCircleCropSelection(width, height, { ...bounded, centerX: bounded.centerX - sourceDeltaX / width, centerY: bounded.centerY - sourceDeltaY / height });
}

/** Resize from a captured screen-space delta; zero movement never changes size. */
export function resizeCircleCropByScreenDelta(width        , height        , crop           , screenDelta        , sourceToScreenScale        )            {
  if (![screenDelta, sourceToScreenScale].every(Number.isFinite) || sourceToScreenScale <= 0) throw Error('Circle resize needs finite screen geometry.');
  const bounded = clampCircleCropSelection(width, height, crop), radius = bounded.radiusX * width + screenDelta / sourceToScreenScale;
  return resizeCircleAtFixedCenter(width, height, bounded, radius);
}

export function circleCropExportMapping(width        , height        , size        , crop           ) {
  validDimensions(width, height);
  if (!Number.isFinite(size) || size <= 0) throw Error('Output size must be positive.');
  const selection = clampCircleCropSelection(width, height, crop), radius = selection.radiusX * width;
  const centerX = selection.centerX * width, centerY = selection.centerY * height;
  return { sourceX: centerX - radius, sourceY: centerY - radius, sourceWidth: radius * 2, sourceHeight: radius * 2, sourceCenterX: centerX, sourceCenterY: centerY, sourceRadiusX: radius, sourceRadiusY: radius, outputSize: size, rotation: selection.rotation, selection };
}

/** Screen geometry for one fixed aperture with a translated source photo. */
export function fixedCirclePreviewGeometry(width        , height        , crop           , size        ) {
  validDimensions(width, height);
  if (!Number.isFinite(size) || size <= 0) throw Error('Preview size must be positive.');
  const selection = clampCircleCropSelection(width, height, crop), placement = sourceImagePlacement(width, height, size), centerX = size / 2, centerY = size / 2;
  return { scale: placement.scale, centerX, centerY, radius: selection.radiusX * width * placement.scale, imageX: centerX - selection.centerX * placement.width, imageY: centerY - selection.centerY * placement.height, imageWidth: placement.width, imageHeight: placement.height };
}

export function sourceImagePlacement(width        , height        , size        ) {
  validDimensions(width, height);
  if (!Number.isFinite(size) || size <= 0) throw Error('Preview size must be positive.');
  const scale = Math.min(size / width, size / height);
  return { x: (size - width * scale) / 2, y: (size - height * scale) / 2, width: width * scale, height: height * scale, scale };
}

export function cropExportMapping(width        , height        , size        , crop           ) {
  validDimensions(width, height);
  if (!Number.isFinite(size) || size <= 0) throw Error('Output size must be positive.');
  const selection = clampCropSelection(width, height, crop), radiusX = selection.radiusX * width, radiusY = selection.radiusY * height;
  const centerX = selection.centerX * width, centerY = selection.centerY * height;
  return { sourceX: centerX - radiusX, sourceY: centerY - radiusY, sourceWidth: radiusX * 2, sourceHeight: radiusY * 2, sourceCenterX: centerX, sourceCenterY: centerY, sourceRadiusX: radiusX, sourceRadiusY: radiusY, outputSize: size, rotation: selection.rotation, selection };
}

// No store, persistence, sibling view or app boot is created by importing this module.
export async function mountUpload({ root, experience, onSaved = (_address        ) => {}, random = Math.random }   
                                                                                                                                
 ) {
const $ = (id        ) => root.querySelector             (`#${id}`) ;
const input = (id        ) => $(id)                    ;
const discView = createDiscView(experience);
const catalogReady = experience.catalogAvailable;
if (!catalogReady) {
  const notice = document.createElement('p'); notice.className = 'subtle mold-catalog-error'; notice.setAttribute('role', 'alert');
  notice.textContent = 'The mold catalog could not be verified. Mold search and saving are unavailable. Reload DiscStudio to retry.';
  root.querySelector('.workspace')?.prepend(notice);
  $('mold-search-status').textContent = 'Mold catalog unavailable. Reload DiscStudio to retry.';
}
const samplePicker = $('sample-discs');
samplePicker.replaceChildren(...sampleDiscs.map(sample => {
  const button = document.createElement('button'); button.type = 'button'; button.className = 'sample-disc';
  button.dataset.sampleId = sample.id; button.setAttribute('aria-label', `Try ${sample.manufacturer} ${sample.mold} sample photo`);
  const image = document.createElement('img'); image.src = sample.photo; image.alt = '';
  const copy = document.createElement('span'); copy.textContent = `${sample.manufacturer} · ${sample.mold}`;
  button.append(image, copy); return button;
}));
if (!catalogReady) {
  input('mold-search').disabled = true; input('photo').disabled = true;
  input('save').disabled = true; input('shuffle').disabled = true;
  samplePicker.querySelectorAll                   ('button').forEach(button => button.disabled = true);
}
function enforceCatalogAvailability() {
  if (catalogReady) return;
  input('mold-search').disabled = true; input('photo').disabled = true;
  input('save').disabled = true; input('shuffle').disabled = true;
  samplePicker.querySelectorAll                   ('button').forEach(button => button.disabled = true);
}
// Painting machinery remains available as a solved capability, but the base
// Kompozition is photo-first. The painted-discs overlay binds it back into
// the creator experience without deleting or forking the underlying code.
let painting            = { kind: 'painted', name: 'pressed-fern', src: './art/pressed-fern.svg' };
let depiction            = painting, photo                   = null;
let savedPhotoConsumed = false;
function photoDraftView(image           ) {
  const figure = document.createElement('figure');
  const art = document.createElement('div'); art.className = 'disc-art photo-art';
  const img = document.createElement('img'); img.src = image.src; img.alt = 'Prepared photo of your disc'; art.append(img);
  const title = document.createElement('h3'); title.textContent = 'Photo ready';
  const note = document.createElement('p'); note.textContent = 'Select a manufacturer and mold.';
  figure.append(title, art, note); return figure;
}
function nextUploadView() {
  const figure = document.createElement('figure');
  const title = document.createElement('h3'); title.textContent = 'Add another disc';
  const note = document.createElement('p'); note.textContent = 'Added to Today’s Bag.';
  figure.append(title, note); return figure;
}
function resetPaintSeed() { input('paint-seed').value = String(recipeFromDraft(initialDraft(), painting).seed); }
function recipe(material       ) {
  if (!input('paint-seed').value.trim()) throw Error('Enter a painting seed.');
  const selected = experience.seedAt(material.mold);
  const label = input('customize-label').checked ? (input('paint-label').value.trim() || `${selected.manufacturer} · ${selected.name}`) : null;
  return validatePaintRecipe({ ...recipeFromDraft(material, painting), seed: Number(input('paint-seed').value), label });
}
let photoBusy = false;
const defaults = initialDraft();
                                                                    
const seedLabel = ({ seed }            ) => `${seed.manufacturer} · ${seed.name}`;
let visibleSeeds               = [], activeSeed = -1;
let selectionSerial = 0;
function eligibleSeeds(query = '') { return experience.seedOptions(query); }
function closeSeedChoices() {
  $('mold-options').hidden = true; input('mold-search').setAttribute('aria-expanded', 'false'); input('mold-search').removeAttribute('aria-activedescendant'); activeSeed = -1;
}
function renderSeedChoices(query = input('mold-search').value) {
  if (!catalogReady) { visibleSeeds = []; $('mold-options').replaceChildren(); closeSeedChoices(); return; }
  // Query the complete compiled name trie; never prefix-gate a fuzzy ranking
  // or cache only the first source rows.
  try { visibleSeeds = eligibleSeeds(query); }
  catch (error) {
    if (!(error instanceof Error) || error.name !== 'MoldWildcardQueryError') throw error;
    visibleSeeds = []; $('mold-options').replaceChildren(); closeSeedChoices();
    input('mold-search').setAttribute('aria-invalid', 'true'); input('save').disabled = true;
    $('mold-search-status').textContent = 'Adjacent * characters are invalid inside a query. A trailing run is treated as a prefix.';
    $('status').textContent = 'Use one * for one character; adjacent * characters are only valid at the end.';
    return;
  }
  input('mold-search').removeAttribute('aria-invalid');
  $('mold-search-status').textContent = visibleSeeds.length ? `${visibleSeeds.length} matching mold names. Choose one.` : 'No matching mold names.';
  $('mold-options').replaceChildren(...visibleSeeds.map((row, index) => {
    const option = document.createElement('div'); option.id = `mold-option-${index}`; option.setAttribute('role', 'option'); option.setAttribute('aria-selected', 'false'); option.textContent = seedLabel(row);
    option.addEventListener('pointerdown', event => { event.preventDefault(); chooseSeed(row); }); return option;
  }));
  $('mold-options').hidden = visibleSeeds.length === 0; input('mold-search').setAttribute('aria-expanded', String(visibleSeeds.length > 0)); activeSeed = -1;
}
async function chooseSeed(row            ) {
  if (!catalogReady) return;
  const token = ++selectionSerial;
  // Load catalog facts before committing the address, so the crop, metadata,
  // card renderer, and retained bag all start from the same mold values.
  const hydrated = await experience.hydrateSeed(row.address);
  if (token !== selectionSerial) return;
  input('seed').value = hydrated.address; input('mold-search').value = seedLabel({ ...row, seed: hydrated.seed }); closeSeedChoices(); suggestPlastics();
  if (photo) { $('photo-status').textContent = 'Photo ready.'; $('status').textContent = 'Photo ready.'; }
  const next = photo ? await experience.selectDraftDepiction(random) : painting;
  // Photo-first: a draft photo wins over a fresh painting. `painting` must stay
  // painted because recipeFromDraft throws otherwise. A photo Part from a
  // previous (already saved) draft is stale, so only take the photo when the
  // in-memory draft photo agrees with it.
  if (next.kind === 'painted') { painting = next; depiction = next; }
  else if (photo && next.src === photo.src) depiction = next;
  resetPaintSeed(); preview();
}
// Start with an honest empty composer. The mold input is the first decision;
// no catalog item or plastic should be implied before the user chooses one.
input('mold-search').value = '';
input('seed').value = '';
const overrides = document.createElement('details');
overrides.innerHTML = '<summary>Override flight numbers</summary><p>Use catalog values unless overridden. Leave an override blank if unknown.</p>' + flightFields.map(field => `<label><span><input id="own-${field}" type="checkbox"> Override ${field}</span><input id="disc-${field}" aria-label="Disc ${field}" type="number" step="any" disabled></label>`).join('');
$('flight').after(overrides);
for (const field of flightFields) input(`own-${field}`).addEventListener('change', () => { input(`disc-${field}`).disabled = !input(`own-${field}`).checked; });
function draft()        {
  const mold = input('seed').value;
  return { mold, nickname: mold ? experience.seedAt(mold).name : '', plastic: input('plastic').value.trim(), weight: null, Color1: input('Color1').value, Color2: input('Color2').value, paintMode: input('paint-mode').value                      , colorPainting: input('color-painting').checked,
    ...Object.fromEntries(flightFields.filter(field => input(`own-${field}`).checked).map(field => [field, input(`disc-${field}`).value === '' ? null : Number(input(`disc-${field}`).value)])) };
}
function preview() {
 try {
  syncDepictionControls();
  const material = draft();
  if (material.mold) {
    const effective = experience.resolve(material);
    $('flight').textContent = `FLIGHT  ${flightFields.map(field => effective[field] ?? '?').join(' / ')}`;
    for (const field of flightFields) input(`disc-${field}`).placeholder = String(experience.seedAt(material.mold)[field] ?? 'Unknown');
  } else $('flight').textContent = '';
  if (!paintedDiscsEnabled && !photo && material.mold) {
   $('depiction-name').textContent = '';
   $('preview').replaceChildren();
   $('status').textContent = 'Add a photo to continue.';
   input('plastic').disabled = false; input('photo').disabled = photoBusy; input('save').disabled = true;
   return;
  }
  if (savedPhotoConsumed && !photo && !paintedDiscsEnabled) {
   $('depiction-name').textContent = '';
   $('preview').replaceChildren(nextUploadView());
   input('photo').disabled = photoBusy; input('save').disabled = true;
   return;
  }
  if (!material.mold) {
   $('flight').textContent = '';
   $('depiction-name').textContent = photo ? photo.name : '';
   $('preview').replaceChildren(...(photo ? [photoDraftView(photo)] : savedPhotoConsumed ? [nextUploadView()] : []));
   input('plastic').disabled = true;
   input('photo').disabled = photoBusy;
   input('save').disabled = true;
   return;
  }
  const resolved = experience.resolve(material);
  input('photo').disabled = photoBusy;
  $('flight').textContent = `FLIGHT  ${flightFields.map(field => resolved[field] ?? '?').join(' / ')}`;
  for (const field of flightFields) input(`disc-${field}`).placeholder = String(experience.seedAt(material.mold)[field] ?? 'Unknown');
  $('depiction-name').textContent = depiction.name.replaceAll('-', ' ');
  input('color-painting').disabled = depiction.kind === 'photo';
  $('paint-help').textContent = depiction.kind === 'photo' ? 'Photos stay untouched; mode changes the backing only.' : '50/50 swaps palettes across the disc. Halo blends center into rim.';
  const customizeLabel = input('customize-label').checked;
  $('paint-label-controls').hidden = !customizeLabel; input('customize-label').setAttribute('aria-expanded', String(customizeLabel));
  (input('depiction-choice')                                ).querySelector                   ('option[value="photo"]') .disabled = !photo;
  input('depiction-choice').value = depiction.kind;
  const art = renderDepiction({ recipe: recipe(material), photo, choice: depiction.kind, seed: experience.seedAt(material.mold) });
  const view=discView(material, depiction, art); $('preview').replaceChildren(view); applyFinishPreview();
 } catch (error) { $('status').textContent = String(error); }
 finally { enforceCatalogAvailability(); }
}
$('composer').addEventListener('input', event => { const id=(event.target               ).id; if (event.target !== $('depiction-choice') && !finishIds.includes(id)) preview(); });
function suggestPlastics() {
  if (!input('seed').value) {
   input('plastic').replaceChildren(new Option('Choose a mold first', ''));
   input('plastic').value = '';
   input('plastic').disabled = true;
   input('save').disabled = true;
   ($('plastic-source')                     ).hidden = true;
   return;
  }
  const seed = experience.seedAt(input('seed').value);
  const guide = plasticGuides[seed.manufacturer] ?? { values: [], source: '' };
  const preferred = input('plastic').value;
  const unavailable = guide.values.length === 0;
  // A guide is a suggestion, not a gate: tournament players can retain an
  // explicit unknown blend when the manufacturer is not in the small guide.
  const choices = ['', ...guide.values.filter(value => value !== 'Unknown / not listed'), 'Unknown / not listed'];
  input('plastic').replaceChildren(...choices.map(value => { const option = document.createElement('option'); option.value = value; option.textContent = value || 'Not specified'; return option; }));
  input('plastic').value = choices.includes(preferred) ? preferred : '';
  input('plastic').disabled = false;
  updateSaveState();
  const link = $('plastic-source')                     ; link.href = guide.source; link.textContent = `${seed.manufacturer} plastic guide`; link.hidden = !guide.source;
}
function updateSaveState() {
 if (!catalogReady) { input('save').disabled = true; return; }
 input('save').disabled = photoBusy || (!photo && !(paintedDiscsEnabled && depiction.kind === 'painted')) || input('plastic').disabled || !input('seed').value;
}
['change', 'input'].forEach(event => input('plastic').addEventListener(event, updateSaveState));
input('mold-search').addEventListener('focus', () => { if (!input('seed').value) renderSeedChoices(); });
input('mold-search').addEventListener('input', () => {
  selectionSerial++;
  input('seed').value = '';
  // Typing is exploratory even when it happens to equal a catalog label;
  // commitment only occurs through an option click or keyboard Enter.
  suggestPlastics(); renderSeedChoices(); preview();
});
input('mold-search').addEventListener('keydown', event => {
  if (event.key === 'Escape') { closeSeedChoices(); return; }
  if (!['ArrowDown', 'ArrowUp', 'Enter'].includes(event.key)) return;
  if (!visibleSeeds.length) return;
  if (event.key === 'Enter' && activeSeed < 0 && visibleSeeds.length === 1) activeSeed = 0;
  else if (event.key === 'ArrowDown') activeSeed = (activeSeed + 1) % visibleSeeds.length;
  else if (event.key === 'ArrowUp') activeSeed = (activeSeed - 1 + visibleSeeds.length) % visibleSeeds.length;
  if (event.key === 'Enter' && activeSeed >= 0) { event.preventDefault(); chooseSeed(visibleSeeds[activeSeed]); return; }
  if (activeSeed >= 0) {
    event.preventDefault(); root.querySelectorAll             ('#mold-options [role="option"]').forEach((option, index) => option.setAttribute('aria-selected', String(index === activeSeed)));
    input('mold-search').setAttribute('aria-activedescendant', `mold-option-${activeSeed}`);
  }
});
input('mold-search').addEventListener('blur', () => { setTimeout(() => { if (!input('seed').value) $('status').textContent = 'Choose a mold from the suggestions.'; closeSeedChoices(); }); });
$('shuffle').addEventListener('click', async () => { if (!paintedDiscsEnabled) return; const next = await experience.selectDraftDepiction(random, true); if (next.kind === 'painted') { painting = next; depiction = next; } resetPaintSeed(); preview(); });
$('depiction-choice').addEventListener('change', () => { if (!paintedDiscsEnabled) { if (photo) depiction = photo; preview(); return; } depiction = input('depiction-choice').value === 'photo' && photo ? photo : painting; preview(); });
const finishIds = ['rim-size', 'underglow', 'stamp-x', 'stamp-y'];
const paintingControls = [...root.querySelectorAll             ('.painting-only')];
function syncDepictionControls() {
  const photoMode = depiction.kind === 'photo';
  root.classList.toggle('photo-mode', photoMode);
  root.classList.toggle('painted-disc-overlay', paintedDiscsEnabled);
  paintingControls.forEach(control => { control.hidden = !paintedDiscsEnabled || photoMode; });
  const switcher = root.querySelector             ('.depiction-switcher');
  if (switcher) switcher.hidden = !paintedDiscsEnabled;
  if (photoMode) {
    input('customize-label').checked = false;
    input('customize-label').setAttribute('aria-expanded', 'false');
    $('paint-label-controls').hidden = true;
  }
}
function applyFinishPreview() {
  const view = $('preview').querySelector             ('figure'); if (!view) return;
  const glow = Number(input('underglow').value), painted = depiction.kind !== 'photo';
  view.classList.add('experimental-preview');
  view.style.setProperty('--exp-rim', `${painted ? Number(input('rim-size').value) : 0}px`);
  view.style.setProperty('--exp-glow-blur', `${Math.round(glow * 34)}px`);
  view.style.setProperty('--exp-glow-spread', `${Math.round(glow * 8)}px`);
  view.style.setProperty('--exp-glow-color', `rgba(230,182,110,${(.25 + glow * .65).toFixed(2)})`);
  view.style.setProperty('--exp-x', `${painted ? Number(input('stamp-x').value) * 8 : 0}%`);
  view.style.setProperty('--exp-y', `${painted ? Number(input('stamp-y').value) * 8 : 0}%`);
}
for (const id of finishIds) input(id).addEventListener('input', applyFinishPreview);
                                                                                                   
let cropBitmap                    = null; let cropFile              = null; let cropWorking                           = null;
let candidateSession                                = null, candidateChoices                    = [], seenCandidates                    = [], selectedCandidate                         = null, candidateBusy = false;
                                                                                                                 
let ellipseFitActive = false, ellipseFitBusy = false, ellipseFitRequest = 0, ellipseDecisionRequired = false;
let ellipseGeometry                         = null, ellipseFitWorker                                                     = null;
let ellipseControlSnapshot                         = null, ellipseEditedControls = new Set        ();
const cropIds = ['crop-center-x', 'crop-center-y', 'crop-radius-x', 'crop-radius-y'];
let cropRotation = 0;
let refitAttempt                                                                = null;
let pendingSampleDetails                                              = null;
// Every new photo or crop action supersedes an in-flight circle request.
let circleFitRequest = 0, circleFitSerial = 0, candidateRequest = 0;
function invalidateCircleFit() { circleFitRequest++; candidateRequest++; candidateBusy = false; syncCandidateApply(); }
function cropState()            { return { centerX: Number(input('crop-center-x').value), centerY: Number(input('crop-center-y').value), radiusX: Number(input('crop-radius-x').value), radiusY: Number(input('crop-radius-y').value), rotation: cropRotation }; }
function setCrop(next           , { invalidate = true }                           = {}) {
  if (!cropWorking || !cropBitmap) return;
  if (invalidate) invalidateCircleFit();
  const crop = clampCircleCropSelection(cropBitmap.width, cropBitmap.height, next);
  input('crop-center-x').value = String(crop.centerX); input('crop-center-y').value = String(crop.centerY);
  cropRotation = crop.rotation;
  input('crop-rotation').value = String(cropRotation * 180 / Math.PI);
  $('crop-rotation-value').textContent = `${Math.round(cropRotation * 180 / Math.PI)}°`;
  input('crop-radius-x').value = String(crop.radiusX); input('crop-radius-y').value = String(crop.radiusY);
  scheduleCropPreview();
}
function circleLockedCrop(width        , height        , ratio = .48)            {
  const radius = Math.min(width, height) * ratio;
  return { centerX:.5, centerY:.5, radiusX:radius / width, radiusY:radius / height, rotation:0 };
}
function resetCrop({ invalidate = true }                           = {}) { if (cropBitmap) setCrop(circleLockedCrop(cropBitmap.width, cropBitmap.height), { invalidate }); }
                                                                                                                                                             
function fixedCropView(crop           , size        )                  {
  return cropBitmap ? fixedCirclePreviewGeometry(cropBitmap.width, cropBitmap.height, crop, size) : null;
}
                                                                                                                                                                          
let cropGesture                     = null;
const cropStage = $('crop-stage');
const resizeHandle = $('crop-resize-handle')                     ;
const gestureState = $('crop-gesture-state');
function setGestureState(mode                            ) {
  if (ellipseFitActive || ellipseDecisionRequired) {
    cropStage.dataset.mode = 'ellipse';
    gestureState.textContent = ellipseFitActive ? 'Ellipse proposal' : 'Ellipse fit needs choice';
    resizeHandle.hidden = true;
    return;
  }
  cropStage.dataset.mode = mode ?? 'ready';
  gestureState.textContent = mode === 'resize' ? 'Resizing circle' : mode === 'pan' ? 'Panning photo' : 'Circle ready';
  resizeHandle.hidden = false;
}
function drawTransparentGutter(ctx                          , size        ) {
  const cell = Math.max(8, Math.round(size / 28));
  for (let y = 0; y < size; y += cell) for (let x = 0; x < size; x += cell) {
    ctx.fillStyle = ((x / cell + y / cell) & 1) ? '#eef0ec' : '#f8f8f5';
    ctx.fillRect(x, y, cell, cell);
  }
}
/** One candidate tap shows the same full circular cutout that Apply prepares. */
function drawCandidateCutoutPreview(canvas                   , ctx                          ) {
  if (!cropBitmap) return;
  const gutter = Math.max(12, Math.round(canvas.width * .05)), size = canvas.width - gutter * 2;
  drawTransparentGutter(ctx, canvas.width);
  const mapping = circleCropExportMapping(cropBitmap.width, cropBitmap.height, size, cropState());
  ctx.save(); ctx.beginPath(); ctx.ellipse(canvas.width / 2, canvas.height / 2, size / 2, size / 2, 0, 0, Math.PI * 2); ctx.clip();
  ctx.translate(gutter, gutter); drawRotatedCrop(ctx, cropBitmap.image, mapping); ctx.restore();
}
function drawEllipseProposalPreview(canvas                   , ctx                          ) {
  if (!cropBitmap || !cropWorking || !ellipseGeometry) return false;
  const placement = sourceImagePlacement(cropBitmap.width, cropBitmap.height, canvas.width), { centerX, centerY, radiusX, radiusY, axisAngle } = ellipseGeometry;
  ctx.clearRect(0, 0, canvas.width, canvas.height); ctx.fillStyle = '#dfe5db'; ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(cropWorking, placement.x, placement.y, placement.width, placement.height);
  const x = placement.x + centerX * placement.scale, y = placement.y + centerY * placement.scale;
  ctx.save(); ctx.fillStyle = 'rgba(18,39,31,.68)'; ctx.beginPath(); ctx.rect(0, 0, canvas.width, canvas.height); ctx.ellipse(x, y, radiusX * placement.scale, radiusY * placement.scale, axisAngle, 0, Math.PI * 2, true); ctx.fill('evenodd');
  ctx.beginPath(); ctx.ellipse(x, y, radiusX * placement.scale, radiusY * placement.scale, axisAngle, 0, Math.PI * 2); ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(2, canvas.width / 260); ctx.stroke(); ctx.restore();
  return true;
}
function updateCropPreview() {
  if (!cropWorking || !cropBitmap) return;
  setGestureState(cropGesture?.mode ?? null);
  const canvas = $('crop-preview')                     , ctx = canvas.getContext('2d') , showCandidate = !!selectedCandidate && !manualCrop.open;
  const crop = cropState(), circleSize = Math.round(crop.radiusX * cropBitmap.width * 200 / Math.min(cropBitmap.width, cropBitmap.height));
  ($('crop-zoom-value')                     ).value = `Circle size ${circleSize}%`;
  cropStage.dataset.candidate = String(showCandidate && !ellipseFitActive);
  if (ellipseFitActive && drawEllipseProposalPreview(canvas, ctx)) {
    canvas.setAttribute('aria-label', 'Ellipse fit preview. The proposed rim and editable ellipse are shown over the original photo.');
    return;
  }
  canvas.setAttribute('aria-label', 'Photo crop preview');
  if (showCandidate) { drawCandidateCutoutPreview(canvas, ctx); return; }
  const view = fixedCropView(crop, canvas.width); if (!view) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height); ctx.fillStyle = '#dfe5db'; ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.save(); ctx.translate(view.centerX, view.centerY); ctx.rotate(crop.rotation); ctx.translate(-view.centerX, -view.centerY);
  ctx.drawImage(cropWorking, view.imageX, view.imageY, view.imageWidth, view.imageHeight); ctx.restore();
  const mode = cropGesture?.mode, stroke = mode === 'resize' ? '#d88938' : mode === 'pan' ? '#168a87' : 'rgba(255,255,255,.96)';
  // The source image moves beneath one fixed circular aperture. The whole
  // outline changes only while a captured gesture is active.
  ctx.save(); ctx.fillStyle = 'rgba(18,39,31,.68)'; ctx.beginPath(); ctx.rect(0, 0, canvas.width, canvas.height); ctx.arc(view.centerX, view.centerY, view.radius, 0, Math.PI * 2, true); ctx.fill('evenodd'); ctx.beginPath(); ctx.arc(view.centerX, view.centerY, view.radius, 0, Math.PI * 2); ctx.strokeStyle = stroke; ctx.lineWidth = Math.max(2, canvas.width / 260); ctx.stroke(); ctx.restore();
  cropStage.style.setProperty('--crop-handle-x', `${view.radius / Math.SQRT2 / canvas.width * 100}%`);
  cropStage.style.setProperty('--crop-handle-y', `${view.radius / Math.SQRT2 / canvas.height * 100}%`);
}
const candidatePicker = $('circle-candidate-picker'), candidateList = $('circle-candidates'), candidateHeading = $('circle-candidate-heading'), refineButton = $('crop-refine')                     , otherButton = $('crop-other')                     , cropApply = $('crop-apply')                     ;
const manualCrop = $('crop-manual')                      ;
const ellipseFitButton = $('crop-ellipse-fit')                     , ellipseControls = $('crop-ellipse-controls')                       , ellipseStatus = $('crop-ellipse-status');
const ellipseCenterX = input('crop-ellipse-center-x'), ellipseCenterY = input('crop-ellipse-center-y'), ellipseRadiusX = input('crop-ellipse-radius-x'), ellipseRadiusY = input('crop-ellipse-radius-y'), ellipseAxisAngle = input('crop-ellipse-axis-angle');
const ellipseRangeControls = [ellipseCenterX, ellipseCenterY, ellipseRadiusX, ellipseRadiusY, ellipseAxisAngle];
function ellipseShortSide() { return cropBitmap ? Math.min(cropBitmap.width, cropBitmap.height) : 1; }
function ellipseMajorRadiusLimit() { return cropBitmap ? Math.max(cropBitmap.width, cropBitmap.height) / (2 * ellipseShortSide()) : .5; }
function validEllipse(geometry                        )                              {
  if (!cropBitmap || !geometry || geometry.radiusX < geometry.radiusY) return false;
  return validateEllipseBounds(cropBitmap.width, cropBitmap.height, geometry, 0);
}
function ellipseFitsControlRanges(geometry                        ) {
  if (!cropBitmap || !geometry) return false;
  const shortSide = ellipseShortSide(), major = geometry.radiusX / shortSide, minor = geometry.radiusY / shortSide, degrees = geometry.axisAngle * 180 / Math.PI;
  return major >= .03 && major <= ellipseMajorRadiusLimit() && minor >= .03 && minor <= .5 && degrees >= -90 && degrees <= 90;
}
function readEllipseControls()                         {
  if (!cropBitmap) return null;
  const shortSide = ellipseShortSide();
  const values = [ellipseCenterX.value, ellipseCenterY.value, ellipseRadiusX.value, ellipseRadiusY.value, ellipseAxisAngle.value].map(Number);
  if (!values.every(Number.isFinite)) return null;
  return { centerX: values[0] * cropBitmap.width, centerY: values[1] * cropBitmap.height, radiusX: values[2] * shortSide, radiusY: values[3] * shortSide, axisAngle: values[4] * Math.PI / 180 };
}
function syncEllipseControls({ geometry, activate = ellipseFitActive, preserveExact = false }                                                                                     = {}) {
  if (cropBitmap) {
    ellipseRadiusX.max = String(ellipseMajorRadiusLimit());
    ellipseRadiusY.max = '.5';
  }
  if (geometry && cropBitmap) {
    ellipseCenterX.value = String(geometry.centerX / cropBitmap.width); ellipseCenterY.value = String(geometry.centerY / cropBitmap.height);
    ellipseRadiusX.value = String(geometry.radiusX / ellipseShortSide()); ellipseRadiusY.value = String(geometry.radiusY / ellipseShortSide());
    ellipseAxisAngle.value = String(geometry.axisAngle * 180 / Math.PI);
    // Range inputs quantize their displayed values. Preserve exact physical
    // geometry only when reopening a saved V2; fresh proposals apply the shown
    // range values so the preview, controls, and prepared raster agree.
    ellipseControlSnapshot = preserveExact ? { ...geometry } : null; ellipseEditedControls.clear();
  }
  const centerXValue = $('crop-ellipse-center-x-value'), centerYValue = $('crop-ellipse-center-y-value'), radiusXValue = $('crop-ellipse-radius-x-value'), radiusYValue = $('crop-ellipse-radius-y-value'), axisValue = $('crop-ellipse-axis-angle-value');
  centerXValue.textContent = `${(Number(ellipseCenterX.value) * 100).toFixed(1)}%`; centerYValue.textContent = `${(Number(ellipseCenterY.value) * 100).toFixed(1)}%`;
  radiusXValue.textContent = `${(Number(ellipseRadiusX.value) * 100).toFixed(1)}%`; radiusYValue.textContent = `${(Number(ellipseRadiusY.value) * 100).toFixed(1)}%`;
  axisValue.textContent = `${Math.round(Number(ellipseAxisAngle.value))}°`;
  const enteredGeometry = readEllipseControls();
  if (ellipseControlSnapshot && enteredGeometry) {
    ellipseGeometry = { ...ellipseControlSnapshot };
    const controlKeys                                         = [
      [ellipseCenterX.id, 'centerX'], [ellipseCenterY.id, 'centerY'],
      [ellipseRadiusX.id, 'radiusX'], [ellipseRadiusY.id, 'radiusY'],
      [ellipseAxisAngle.id, 'axisAngle'],
    ];
    for (const [controlId, property] of controlKeys) {
      if (ellipseEditedControls.has(controlId)) ellipseGeometry[property] = enteredGeometry[property];
    }
  } else ellipseGeometry = enteredGeometry;
  ellipseFitActive = activate;
  ellipseControls.hidden = !ellipseFitActive; ellipseFitButton.setAttribute('aria-expanded', String(ellipseFitActive));
  ellipseRangeControls.forEach(control => { control.disabled = ellipseFitBusy || !ellipseFitActive; });
  if (ellipseFitActive && !ellipseFitBusy) ellipseStatus.textContent = validEllipse(ellipseGeometry) ? 'Ellipse proposal needs your review. Stamp rotation above stays independent.' : 'This ellipse crosses the photo edge or has invalid radii. Use photo is disabled until corrected.';
}
function invalidateEllipseFit() {
  ellipseFitRequest++; ellipseFitBusy = false; ellipseFitButton.disabled = false;
  syncCandidateApply();
}
function clearEllipseFit(message         ) {
  invalidateEllipseFit(); ellipseFitActive = false; ellipseDecisionRequired = false; ellipseGeometry = null; ellipseControlSnapshot = null; ellipseEditedControls.clear(); ellipseControls.hidden = true; ellipseFitButton.setAttribute('aria-expanded', 'false');
  ellipseStatus.textContent = message ?? 'Circle fit remains the default. Ellipse fitting is opt-in.';
  syncCandidateApply(); scheduleCropPreview();
}
function syncCandidateApply() {
  const circleReady = !ellipseDecisionRequired && (!!selectedCandidate || manualCrop.open);
  const ellipseReady = ellipseFitActive && validEllipse(ellipseGeometry);
  cropApply.disabled = candidateBusy || ellipseFitBusy || !cropBitmap || !cropFile || !(ellipseFitActive ? ellipseReady : circleReady);
  ellipseFitButton.disabled = ellipseFitBusy || !cropBitmap || !cropFile;
}
function syncManualMode() {
  cropStage.dataset.manual = String(manualCrop.open);
  cropStage.dataset.candidate = String(!!selectedCandidate && !manualCrop.open);
  resizeHandle.disabled = !manualCrop.open || ellipseFitActive || ellipseDecisionRequired;
  resizeHandle.hidden = ellipseFitActive || ellipseDecisionRequired;
  syncCandidateApply(); requestAnimationFrame(sizeCropStage);
}
async function tryEllipseFit() {
  if (!cropBitmap || !cropFile || ellipseFitBusy) return;
  const bitmap = cropBitmap, request = ++ellipseFitRequest;
  ellipseDecisionRequired = true;
  invalidateCircleFit(); endCropGesture(); ellipseFitBusy = true;
  if (manualCrop.open) { manualCrop.open = false; syncManualMode(); }
  ellipseRangeControls.forEach(control => { control.disabled = true; });
  ellipseStatus.textContent = 'Trying ellipse fit on the original photo…'; ellipseFitButton.disabled = true;
  refineButton.disabled = true; otherButton.disabled = true; syncCandidateApply();
  const raster = document.createElement('canvas'); raster.width = bitmap.width; raster.height = bitmap.height;
  try {
    const context = raster.getContext('2d', { willReadFrequently: true });
    if (!context) throw Error('The original photo raster is unavailable.');
    context.drawImage(bitmap.image, 0, 0, bitmap.width, bitmap.height);
    const data = context.getImageData(0, 0, bitmap.width, bitmap.height).data;
    ellipseFitWorker ??= createRimFitWorkerClient();
    const result = await ellipseFitWorker.recover({ width: bitmap.width, height: bitmap.height, data }, { maxRefinementDimension: 384 });
    if (request !== ellipseFitRequest || bitmap !== cropBitmap) return;
    const proposal = adaptRimFitResult(result, { data, width: bitmap.width, height: bitmap.height, maxRefinementDimension: 384 });
    if (proposal.status !== 'MAYBE' || !proposal.ellipse || !validEllipse(proposal.ellipse) || !ellipseFitsControlRanges(proposal.ellipse)) {
      ellipseFitActive = false; ellipseGeometry = null; ellipseControls.hidden = false; ellipseFitButton.setAttribute('aria-expanded', 'true');
      ellipseRangeControls.forEach(control => { control.disabled = true; });
      const reason = typeof proposal.reason === 'string' ? proposal.reason.replaceAll('-', ' ') : 'no bounded outer rim was found';
      ellipseStatus.textContent = `Ellipse fit did not produce an editable proposal (${reason}). Choose Use circle fit to restore the circle path.`;
    } else {
      syncEllipseControls({ geometry: proposal.ellipse, activate: true });
      ellipseStatus.textContent = 'MAYBE ellipse proposal. Review the visible rim and adjust its controls before Use photo.';
    }
    scheduleCropPreview(); syncCandidateApply();
  } catch (error) {
    if (request === ellipseFitRequest && bitmap === cropBitmap) {
      ellipseFitActive = false; ellipseGeometry = null; ellipseControls.hidden = false; ellipseFitButton.setAttribute('aria-expanded', 'true');
      ellipseRangeControls.forEach(control => { control.disabled = true; });
      ellipseStatus.textContent = 'Ellipse fit unavailable. Choose Use circle fit to restore the circle path.';
      syncCandidateApply(); scheduleCropPreview();
    }
  } finally {
    raster.width = 0; raster.height = 0;
    if (request === ellipseFitRequest) {
      ellipseFitBusy = false; ellipseFitButton.disabled = false;
      ellipseRangeControls.forEach(control => { control.disabled = !ellipseFitActive; });
      refineButton.disabled = candidateBusy || !selectedCandidate; otherButton.disabled = candidateBusy || candidateChoices.length === 0;
      syncCandidateApply();
    }
  }
}
function restoreCircleFit() {
  clearEllipseFit('Circle fit restored. Ellipse fitting remains opt-in.');
  if (!selectedCandidate) manualCrop.open = true;
  syncManualMode(); scheduleCropPreview();
  $('photo-crop-help').textContent = 'Circle fit restored. Adjust manually or choose a detected circle, then use Use photo.';
}
function candidateCrop(candidate                 ) {
  return cropBitmap ? cropForDetectedCircle(cropBitmap.width, cropBitmap.height, candidate.circle) : null;
}
function drawCandidateThumbnail(canvas                   , candidate                 , selected         ) {
  if (!cropWorking || !cropBitmap) return;
  const crop = candidateCrop(candidate); if (!crop) return;
  const context = canvas.getContext('2d') , view = fixedCirclePreviewGeometry(cropBitmap.width, cropBitmap.height, crop, canvas.width);
  context.clearRect(0, 0, canvas.width, canvas.height); context.fillStyle = '#dfe5db'; context.fillRect(0, 0, canvas.width, canvas.height);
  context.drawImage(cropWorking, view.imageX, view.imageY, view.imageWidth, view.imageHeight);
  context.save(); context.fillStyle = 'rgba(18,39,31,.58)'; context.beginPath(); context.rect(0, 0, canvas.width, canvas.height); context.arc(view.centerX, view.centerY, view.radius, 0, Math.PI * 2, true); context.fill('evenodd'); context.beginPath(); context.arc(view.centerX, view.centerY, view.radius, 0, Math.PI * 2); context.strokeStyle = selected ? '#168a87' : '#fff'; context.lineWidth = 2; context.stroke(); context.restore();
}
function renderCandidateChoices() {
  candidateList.replaceChildren();
  candidatePicker.hidden = candidateChoices.length === 0;
  candidateHeading.textContent = candidateChoices.length ? 'Pick the closest circle' : 'No circle choices yet';
  const fragment = document.createDocumentFragment();
  candidateChoices.forEach((candidate, index) => {
    const selected = selectedCandidate?.id === candidate.id;
    const button = document.createElement('button'); button.type = 'button'; button.className = 'circle-candidate'; button.setAttribute('aria-pressed', String(selected));
    const canvas = document.createElement('canvas'); canvas.width = 128; canvas.height = 128; canvas.setAttribute('aria-hidden', 'true'); drawCandidateThumbnail(canvas, candidate, selected);
    const label = document.createElement('span'); const reference = candidateChoices[0];
    const dr = candidate.circle.radius - reference.circle.radius, dx = candidate.circle.x - reference.circle.x, dy = candidate.circle.y - reference.circle.y;
    const explanation = index === 0 ? 'Initial crop' : Math.abs(dr) > 1 ? dr > 0 ? 'Larger crop' : 'Smaller crop' : Math.abs(dx) > Math.abs(dy) ? dx > 0 ? 'Shifted right' : 'Shifted left' : Math.abs(dy) > 1 ? dy > 0 ? 'Shifted downward' : 'Shifted upward' : 'Nearby crop';
    label.textContent = `Choice ${index + 1} · ${explanation}`; button.setAttribute('aria-label', `Choice ${index + 1}, ${explanation}${selected ? ', selected' : ''}`);
    button.append(canvas, label); button.addEventListener('click', () => chooseCandidate(candidate)); fragment.append(button);
  });
  candidateList.append(fragment); refineButton.disabled = candidateBusy || ellipseFitBusy || !selectedCandidate; otherButton.disabled = candidateBusy || ellipseFitBusy || candidateChoices.length === 0; syncCandidateApply(); requestAnimationFrame(sizeCropStage);
}
function clearCandidateSelection() { if (!selectedCandidate) return; selectedCandidate = null; renderCandidateChoices(); }
function chooseCandidate(candidate                 ) {
  const crop = candidateCrop(candidate); if (!crop) return;
  clearEllipseFit('Circle selected. Ellipse fitting remains opt-in.'); invalidateCircleFit(); manualCrop.open = false; syncManualMode(); selectedCandidate = candidate; setCrop(crop, { invalidate: false }); renderCandidateChoices();
  $('photo-crop-help').textContent = 'Circle selected. Refine choice stays near it, or use this circle as-is.';
}
function resetCandidateChoices() {
  candidateChoices = []; seenCandidates = []; selectedCandidate = null; renderCandidateChoices();
}
function sameCandidateCircle(a                 , b                 ) {
  return a.id === b.id && a.circle.x === b.circle.x && a.circle.y === b.circle.y && a.circle.radius === b.circle.radius && a.circle.confidence === b.circle.confidence;
}
async function loadCircleCandidates(operation                                ) {
  const session = candidateSession, bitmap = cropBitmap, working = cropWorking, anchor = selectedCandidate;
  if (!session || !bitmap || !working || (operation === 'refine' && !anchor)) return;
  const previousChoices = candidateChoices, previousSelection = selectedCandidate;
  const request = ++candidateRequest;
  if (operation === 'initial') { candidateChoices = []; seenCandidates = []; selectedCandidate = null; manualCrop.open = false; syncManualMode(); }
  candidateBusy = true; renderCandidateChoices(); refineButton.disabled = true; otherButton.disabled = true;
  $('photo-crop-help').textContent = operation === 'refine' ? 'Refining around your selected circle…' : operation === 'other' ? 'Finding other circles…' : 'Finding circle choices…';
  try {
    const result = await composeCircleCandidateChoices(experience.pxc, session, ++circleFitSerial, { operation, ...(operation === 'refine' && anchor ? { selected: anchor } : {}), ...(operation === 'other' ? { excluded: seenCandidates } : {}) });
    if (request !== candidateRequest || session !== candidateSession || bitmap !== cropBitmap || working !== cropWorking) return;
    candidateBusy = false;
    const rows = result.proposal.status === 'accepted' ? result.proposal.candidates                      : [];
    if (!rows.length) {
      if ((operation === 'other' || operation === 'refine') && previousSelection) {
        candidateChoices = previousChoices; selectedCandidate = previousSelection; renderCandidateChoices();
        $('photo-crop-help').textContent = operation === 'refine' ? 'No better crop was found. Your selected circle is still ready to use.' : 'No other supported circles were found. Your selected circle is still ready to use.';
        return;
      }
      candidateChoices = []; selectedCandidate = null; renderCandidateChoices(); manualCrop.open = true; syncManualMode();
      $('photo-crop-help').textContent = 'Could not confirm distinct circles. Adjust manually if needed.';
      return;
    }
    if (operation === 'refine') {
      if (!anchor || !sameCandidateCircle(rows[0], anchor)) throw Error('Refine did not retain the selected circle.');
      selectedCandidate = rows[0];
    }
    candidateChoices = rows;
    if (operation === 'initial' || operation === 'other') { seenCandidates = [...seenCandidates, ...rows]; if (operation === 'other') selectedCandidate = null; }
    renderCandidateChoices();
    $('photo-crop-help').textContent = operation === 'refine' ? 'Your circle is kept first. Choose a nearby alternative only if it looks better.' : 'Pick the closest circle, then refine it if needed.';
  } catch {
    if (request !== candidateRequest || session !== candidateSession) return;
    candidateBusy = false; candidateChoices = previousChoices; selectedCandidate = previousSelection; renderCandidateChoices(); if (!previousSelection) manualCrop.open = true; syncManualMode();
    $('photo-crop-help').textContent = previousSelection ? 'Choices unavailable. Your selected circle is still ready to use.' : 'Circle choices were unavailable. Adjust manually if needed.';
  }
}
let cropFrame = 0;
function scheduleCropPreview() { if (cropFrame) return; cropFrame = requestAnimationFrame(() => { cropFrame = 0; updateCropPreview(); }); }
function sizeCropStage() {
  if (cropGesture) return;
  cropStage.style.width = ''; cropStage.style.height = '';
  const width = cropStage.clientWidth, height = cropStage.clientHeight;
  const side = Math.floor(Math.min(width, height > 0 ? height : Math.min(width, 320)));
  if (side > 0) {
    cropStage.parentElement .style.gridTemplateRows = `auto auto ${side}px auto auto auto auto auto`;
    cropStage.style.width = `${side}px`; cropStage.style.height = `${side}px`; scheduleCropPreview();
  }
}
const cropStageResize = new ResizeObserver(sizeCropStage); cropStageResize.observe(cropStage.parentElement );
function stagePoint(event              ) { const rect = cropStage.getBoundingClientRect(); return { x:event.clientX - rect.left, y:event.clientY - rect.top }; }
function currentStageView(crop           ) { const rect = cropStage.getBoundingClientRect(); return fixedCropView(crop, Math.min(rect.width, rect.height)); }
function beginCropGesture(event              , mode                     ) {
  if (!manualCrop.open || cropGesture || !event.isPrimary || event.button !== 0 || !cropWorking || !cropBitmap) return;
  if (ellipseFitActive) clearEllipseFit('Manual circle adjustment selected. Ellipse fitting remains opt-in.');
  const crop = cropState(), view = currentStageView(crop); if (!view) return;
  const point = stagePoint(event);
  cropGesture = { mode, pointerId: event.pointerId, startClientX: event.clientX, startClientY: event.clientY, startPointerRadius: Math.hypot(point.x - view.centerX, point.y - view.centerY), crop, view };
  invalidateCircleFit(); clearCandidateSelection(); setGestureState(mode); cropStage.setPointerCapture(event.pointerId); scheduleCropPreview(); event.preventDefault();
}
function endCropGesture(event               ) {
  if (!cropGesture || (event && event.pointerId !== cropGesture.pointerId)) return;
  cropGesture = null; setGestureState(null); scheduleCropPreview();
}
resizeHandle.addEventListener('pointerdown', event => { event.stopPropagation(); beginCropGesture(event, 'resize'); });
cropStage.addEventListener('pointerdown', event => beginCropGesture(event, 'pan'));
cropStage.addEventListener('pointermove', event => {
  const gesture = cropGesture; if (!gesture || event.pointerId !== gesture.pointerId || !cropBitmap) return;
  if (gesture.mode === 'pan') {
    const sourceX = (event.clientX - gesture.startClientX) / gesture.view.scale, sourceY = (event.clientY - gesture.startClientY) / gesture.view.scale;
    setCrop(panCircleCrop(cropBitmap.width, cropBitmap.height, gesture.crop, sourceX * Math.cos(gesture.crop.rotation) + sourceY * Math.sin(gesture.crop.rotation), -sourceX * Math.sin(gesture.crop.rotation) + sourceY * Math.cos(gesture.crop.rotation)), { invalidate: false });
  } else {
    const point = stagePoint(event), delta = Math.hypot(point.x - gesture.view.centerX, point.y - gesture.view.centerY) - gesture.startPointerRadius;
    setCrop(resizeCircleCropByScreenDelta(cropBitmap.width, cropBitmap.height, gesture.crop, delta, gesture.view.scale), { invalidate: false });
  }
});
for (const eventName of ['pointerup', 'pointercancel', 'lostpointercapture']) cropStage.addEventListener(eventName, event => endCropGesture(event                ));
function stepZoom(deltaPercent       ){ if (cropBitmap) { clearEllipseFit('Manual circle adjustment selected. Ellipse fitting remains opt-in.'); invalidateCircleFit(); clearCandidateSelection(); setCrop(resizeCircleCrop(cropBitmap.width, cropBitmap.height, cropState(), deltaPercent), { invalidate:false }); } }
for (const button of root.querySelectorAll                   ('[data-zoom-delta]')) button.addEventListener('click',()=>stepZoom(Number(button.dataset.zoomDelta)));
function startOverCircleChoices() {
  if (!candidateSession || !cropBitmap) return;
  clearEllipseFit(); invalidateCircleFit(); resetCrop({ invalidate: false }); loadCircleCandidates('initial');
}
$('crop-auto').addEventListener('click', startOverCircleChoices);
refineButton.addEventListener('click', () => loadCircleCandidates('refine'));
otherButton.addEventListener('click', () => loadCircleCandidates('other'));
ellipseFitButton.addEventListener('click', () => void tryEllipseFit());
$('crop-ellipse-reset').addEventListener('click', restoreCircleFit);
for (const control of ellipseRangeControls) control.addEventListener('input', () => { ellipseEditedControls.add(control.id); syncEllipseControls({ activate: ellipseFitActive }); syncCandidateApply(); scheduleCropPreview(); });
manualCrop.addEventListener('toggle', () => { if (manualCrop.open) { if (ellipseFitActive || ellipseDecisionRequired) clearEllipseFit('Manual circle adjustment selected. Ellipse fitting remains opt-in.'); invalidateCircleFit(); } syncManualMode(); }); syncManualMode();
function discardPendingPhoto() {
  clearEllipseFit(); refitAttempt = null; pendingSampleDetails = null; cropApply.textContent = 'Use photo';
  endCropGesture(); invalidateCircleFit(); candidateSession = null; resetCandidateChoices(); manualCrop.open = false; syncManualMode();
  if (cropBitmap) cropBitmap.dispose(); cropBitmap = null; cropFile = null; cropWorking = null; input('photo').value = '';
  syncCandidateApply();
}
async function decodePhoto(file      )                      {
  if (typeof createImageBitmap === 'function') {
    try {
      const bitmap = await createImageBitmap(file);
      return { image: bitmap, width: bitmap.width, height: bitmap.height, dispose: () => bitmap.close() };
    } catch { /* Safari can decode some camera formats through HTMLImageElement only. */ }
  }
  const url = URL.createObjectURL(file);
  try {
    const image = await new Promise                  ((resolve, reject) => {
      const candidate = new Image(); candidate.decoding = 'async';
      candidate.onload = () => resolve(candidate); candidate.onerror = () => reject(Error('This browser could not decode that photo. Choose another image or export it as JPEG.'));
      candidate.src = url;
    });
    if (!image.naturalWidth || !image.naturalHeight) throw Error('This photo has no usable dimensions.');
    return { image, width: image.naturalWidth, height: image.naturalHeight, dispose: () => URL.revokeObjectURL(url) };
  } catch (error) { URL.revokeObjectURL(url); throw error; }
}
async function openPhoto(file      ) {
  if (!catalogReady) return;
  photoBusy = true; input('photo').disabled = true; input('save').disabled = true; input('shuffle').disabled = true; $('photo-status').textContent = `Preparing ${file.name} on this device…`;
  try {
    if (file.size > 15_000_000) throw Error('Choose a photo under 15 MB. Your prepared photo is unchanged.');
    discardPendingPhoto(); cropFile = file; cropBitmap = await decodePhoto(file);
    const workingScale = Math.min(1, 720 / Math.max(cropBitmap.width, cropBitmap.height)); cropWorking = document.createElement('canvas'); cropWorking.width = Math.max(1, Math.round(cropBitmap.width * workingScale)); cropWorking.height = Math.max(1, Math.round(cropBitmap.height * workingScale)); cropWorking.getContext('2d') .drawImage(cropBitmap.image,0,0,cropWorking.width,cropWorking.height);
    resetCrop({ invalidate: false }); candidateSession = createCircleCandidateSession(experience.pxc, cropBitmap.image, cropBitmap.width, cropBitmap.height, cropWorking, ++circleFitSerial, { clampCropSelection });
    ($('photo-crop')                     ).showModal(); requestAnimationFrame(sizeCropStage); $('crop-cancel').focus(); loadCircleCandidates('initial'); return true;
  } catch (error) { discardPendingPhoto(); photoBusy = false; input('photo').disabled = false; input('shuffle').disabled = false; const message = `Photo could not open: ${String(error).replace(/^Error: /, '')}`; $('photo-status').textContent = message; $('status').textContent = message; updateSaveState(); return false; }
}
async function openRefit(address        ) {
  if (photoBusy) return;
  try {
    if (!experience.shelf().some(row => row.address === address)) throw Error('This disc changed. Open its current version.');
    const held = experience.depictionSources(address).photo;
    if (!held?.refit) throw Error('This earlier photo has no saved re-fit surroundings. Choose a new photo to replace it.');
    const source = validateRefitSource(held.refit);
    photoBusy = true; input('photo').disabled = true; updateSaveState();
    discardPendingPhoto(); cropFile = new File([await (await fetch(source.src)).blob()], held.name); cropBitmap = await decodePhoto(cropFile);
    if (cropBitmap.width !== source.width || cropBitmap.height !== source.height) throw Error('Saved source dimensions differ.');
    const scale = Math.min(1, 720 / Math.max(source.width, source.height)); cropWorking = document.createElement('canvas'); cropWorking.width = Math.max(1, Math.round(source.width * scale)); cropWorking.height = Math.max(1, Math.round(source.height * scale)); cropWorking.getContext('2d') .drawImage(cropBitmap.image, 0, 0, cropWorking.width, cropWorking.height);
    refitAttempt = { address, source, name: held.name };
    if (source.version === 2 && source.kind === 'ellipse') {
      if (!ellipseFitsControlRanges(source)) throw Error('Saved ellipse geometry is outside the editable crop bounds.');
      manualCrop.open = false; syncManualMode();
      setCrop({ centerX: source.centerX / source.width, centerY: source.centerY / source.height, radiusX: Math.min(source.radiusX, source.radiusY) / source.width, radiusY: Math.min(source.radiusX, source.radiusY) / source.height, rotation: source.rotation }, { invalidate: false });
      syncEllipseControls({ geometry: source, activate: true, preserveExact: true });
      ellipseStatus.textContent = 'Saved MAYBE ellipse re-fit reopened. Review the rim and controls before keeping it.';
    } else {
      manualCrop.open = true; syncManualMode();
      setCrop({ centerX: source.centerX / source.width, centerY: source.centerY / source.height, radiusX: source.radius / source.width, radiusY: source.radius / source.height, rotation: source.rotation }, { invalidate: false });
    }
    cropApply.textContent = 'Keep re-fit'; $('photo-crop-help').textContent = 'Adjust within the saved surroundings. Keep re-fit updates this Disc.';
    ($('photo-crop')                     ).showModal(); requestAnimationFrame(sizeCropStage); syncCandidateApply();
  } catch (error) { discardPendingPhoto(); finishPhotoPreparation(); $('status').textContent = `Re-fit could not open: ${String(error).replace(/^Error: /, '')}`; }
}
document.addEventListener('discstudio:refit-disc', event => { const address = (event               ).detail?.address; if (typeof address === 'string') void openRefit(address); });
$('photo').addEventListener('change', () => { const file = input('photo').files?.[0]; if (file) void openPhoto(file); });
samplePicker.addEventListener('click', async event => {
  const button = (event.target               ).closest                   ('.sample-disc');
  if (!button || photoBusy) return;
  const sample = sampleDiscs.find(item => item.id === button.dataset.sampleId);
  if (!sample) return;
  samplePicker.querySelectorAll                   ('button').forEach(item => { item.disabled = true; });
  try {
    const response = await fetch(sample.photo); if (!response.ok) throw Error('Sample photo is unavailable.');
    const file = new File([await response.blob()], sample.filename, { type: 'image/jpeg' });
    const row = experience.seedOptions(sample.mold).find(item => item.seed.id === sample.id);
    if (!row) throw Error(`${sample.mold} is missing from the mold catalog.`);
    if (await openPhoto(file)) pendingSampleDetails = { row, plastic: sample.plastic };
  } catch (error) { const message = `Sample could not open: ${String(error).replace(/^Error: /, '')}`; $('photo-status').textContent = message; $('status').textContent = message; }
  finally { samplePicker.querySelectorAll                   ('button').forEach(item => { item.disabled = false; }); }
});
function finishPhotoPreparation() { photoBusy = false; input('photo').disabled = false; input('shuffle').disabled = false; updateSaveState(); enforceCatalogAvailability(); }
$('crop-cancel').addEventListener('click', () => { const wasRefit = !!refitAttempt; invalidateCircleFit(); ($('photo-crop')                     ).close(); discardPendingPhoto(); const message = wasRefit ? 'Re-fit cancelled. Saved Disc unchanged.' : photo ? 'Photo crop cancelled. Your prepared photo is unchanged.' : 'Photo crop cancelled.'; $('photo-status').textContent = message; $('status').textContent = message; finishPhotoPreparation(); });
$('photo-crop').addEventListener('cancel', event => { event.preventDefault(); $('crop-cancel').click(); });
$('photo-crop').addEventListener('close', () => { endCropGesture(); invalidateCircleFit(); invalidateEllipseFit(); });
input('crop-rotation').addEventListener('input', () => { cropRotation = Number(input('crop-rotation').value) * Math.PI / 180; $('crop-rotation-value').textContent = `${Math.round(Number(input('crop-rotation').value))}°`; scheduleCropPreview(); });
for (const id of cropIds) input(id).addEventListener('input', scheduleCropPreview);
$('crop-reset').addEventListener('click', () => {
  clearEllipseFit(); invalidateCircleFit(); clearCandidateSelection(); resetCrop({ invalidate: false });
  $('photo-crop-help').textContent = 'Circle centered and reset. Drag the photo anywhere to position it, or use the handle to resize.';
});
$('crop-apply').addEventListener('click', async () => {
  const circleReady = !ellipseDecisionRequired && (!!selectedCandidate || manualCrop.open);
  if (!cropBitmap || !cropFile || (ellipseFitActive ? !validEllipse(ellipseGeometry) : !circleReady)) return;
  const apply = cropApply; apply.disabled = true;
  const previousDetails = { seed: input('seed').value, search: input('mold-search').value, plastic: input('plastic').value };
  let sampleDetailsChanged = false;
  try {
    const bitmap = cropBitmap, fileName = cropFile.name, attempt = refitAttempt;
    invalidateCircleFit(); invalidateEllipseFit();
    const photoDepiction            = ellipseFitActive
      ? prepareEllipsePhoto(bitmap.image, bitmap.width, bitmap.height, { ...ellipseGeometry , rotation: cropRotation }, fileName, undefined, attempt?.source)
      : prepareCirclePhoto(bitmap.image, bitmap.width, bitmap.height, clampCircleCropSelection(bitmap.width, bitmap.height, cropState()), fileName, undefined, attempt?.source);
    if (attempt) {
      const candidate = await experience.updateDepiction(attempt.address, { photo: photoDepiction, choice: 'photo' });
      const kept = await experience.keepDisc(attempt.address, candidate);
      ($('photo-crop')                     ).close(); discardPendingPhoto(); finishPhotoPreparation();
      onSaved(kept); $('status').textContent = `Re-fit kept. ${experience.persistenceStatus}`; return;
    }
    if (pendingSampleDetails) {
      const hints = pendingSampleDetails; sampleDetailsChanged = true; await chooseSeed(hints.row);
      if (![...input('plastic').options].some(option => option.value === hints.plastic)) input('plastic').add(new Option(hints.plastic, hints.plastic));
      input('plastic').value = hints.plastic;
    }
    await experience.addDraftPhoto(photoDepiction);
    photo = photoDepiction; depiction = photoDepiction; savedPhotoConsumed = false;
    ($('photo-crop')                     ).close(); discardPendingPhoto(); const message = input('seed').value ? 'Photo ready.' : 'Photo ready. Select a manufacturer and mold.'; $('photo-status').textContent = message; $('status').textContent = message; finishPhotoPreparation(); preview();
  } catch (error) {
    if (sampleDetailsChanged) { input('seed').value = previousDetails.seed; input('mold-search').value = previousDetails.search; suggestPlastics(); input('plastic').value = previousDetails.plastic; }
    ($('photo-crop')                     ).close(); discardPendingPhoto(); const message = `Photo could not be kept: ${String(error).replace(/^Error: /, '')}`; $('photo-crop-help').textContent = message; $('photo-status').textContent = message; $('status').textContent = message; finishPhotoPreparation(); preview();
  } finally { syncCandidateApply(); }
});
$('composer').addEventListener('submit', async event => {
  event.preventDefault(); if (photoBusy || input('save').disabled) return;
  input('save').disabled = true;
  try {
    const material = draft();
    const address = await experience.save(material, depiction, { photo, ...(paintedDiscsEnabled && depiction.kind === 'painted' ? { recipe: recipe(material) } : {}) });
    onSaved(address);
    const storage = experience.persistenceStatus;
    $('status').textContent = storage.startsWith('Saved on this browser')
      ? 'Saved to Today’s Bag.'
      : `Added to Today’s Bag. ${storage}`;
    input('photo').value = '';
    for (const field of flightFields) { input(`own-${field}`).checked = false; input(`disc-${field}`).value = ''; input(`disc-${field}`).disabled = true; }
    // The saved photo is consumed by model.save(). A new composition waits
    // for its own crop instead of reusing an older draft-photo Part.
    depiction = painting; photo = null; savedPhotoConsumed = true;
    $('photo-status').textContent = storage.startsWith('Saved on this browser')
      ? 'Photo saved to Today’s Bag.'
      : 'Photo added for this session only.';
    input('customize-label').checked = false; input('paint-label').value = ''; resetPaintSeed(); preview();
    $('status').textContent = storage.startsWith('Saved on this browser') ? 'Saved to Today’s Bag.' : `Added to Today’s Bag. ${storage}`;
  } catch (error) { $('status').textContent = `Not saved: ${String(error)}`; }
  finally { updateSaveState(); }
});
input('Color1').value = defaults.Color1; input('Color2').value = defaults.Color2; resetPaintSeed(); suggestPlastics(); preview();
// Static HTML keeps actions disabled while the module graph hashes/opens the
// catalog. Enable them only after their listeners and initial view are ready.
if (catalogReady) {
  input('photo').disabled = false; input('mold-search').disabled = false;
  input('shuffle').disabled = !paintedDiscsEnabled; updateSaveState();
  $('mold-search-status').textContent = 'Type a mold prefix; * matches exactly one character.';
} else enforceCatalogAvailability();
if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent('discstudio:upload-ui-ready', {
  detail: { catalogAvailable: catalogReady, readyAt: performance.now() },
}));
return { refresh: preview, openRefit };
}
