import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const escapeHtml = value => String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);

export function readFeatureMaturity(appDirectory) {
  const ledgerName = 'feature-implementation-maturity.json';
  const decisionName = 'feature-version-decision.md';
  const erratumName = 'feature-maturity-erratum.json';
  const ledgerBytes = fs.readFileSync(path.join(appDirectory, ledgerName));
  const decisionBytes = fs.readFileSync(path.join(appDirectory, decisionName));
  const erratumBytes = fs.readFileSync(path.join(appDirectory, erratumName));
  const ledger = JSON.parse(ledgerBytes);
  const erratum = JSON.parse(erratumBytes);
  const stages = ledger.demo?.stages;
  const features = stages?.flatMap(stage => stage.features ?? []);
  const expectedFeatureNames = [
    'Photo intake', 'RimFit', 'Crop refinement and rotation', 'Prepared image creation',
    'Mold and plastic details', 'Save to Today’s Bag', 'Shelf persistence', 'Card selection',
    'Card rendering', 'HighlightColor', 'HighlightOn', 'Mirrored', 'Canvas sizing and placement',
    'Preview', 'Approval / Add to Export', 'Approved graphic rendering', 'Transparent PNG export', 'ZIP packaging',
  ];
  const featureNames = features?.map(feature => feature.name) ?? [];
  const parseVersion = value => {
    const match = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.exec(value ?? '');
    return match ? match.slice(1).map(Number) : null;
  };
  const atLeastVersion = (actual, floor) => {
    const version = parseVersion(actual), minimum = parseVersion(floor);
    if (!version || !minimum) return false;
    for (let index = 0; index < version.length; index++) {
      if (version[index] !== minimum[index]) return version[index] > minimum[index];
    }
    return true;
  };
  const implementationVersionsAreValid = features?.every(feature => parseVersion(feature.implementationVersion) !== null);
  const evolvedFeaturesAreRecorded = ['Preview', 'Mold and plastic details', 'Card rendering'].every(name => {
    const feature = features?.find(item => item.name === name);
    return atLeastVersion(feature?.implementationVersion, '0.1.2') && typeof feature.implementationMilestone === 'string' && feature.implementationMilestone.length > 0;
  });
  const baselineImplementationsAreRecorded = features?.every(feature => ['Preview', 'Mold and plastic details', 'Card rendering'].includes(feature.name)
    || (atLeastVersion(feature.implementationVersion, '0.1.1') && typeof feature.implementationMilestone === 'string' && feature.implementationMilestone.length > 0));
  if (ledger.schema !== 'discstudio-feature-implementation-maturity@1' || ledger.decision !== 'ACCEPTED_PATCH_PROGRESS' || ledger.demo?.version !== '0.0.0' || stages?.length !== 3 || stages.some(stage => stage.version !== '0.0.0') || featureNames.length !== expectedFeatureNames.length || new Set(featureNames).size !== featureNames.length || expectedFeatureNames.some(name => !featureNames.includes(name)) || features?.some(feature => feature.contractVersion !== '0.1.0') || !implementationVersionsAreValid || !evolvedFeaturesAreRecorded || !baselineImplementationsAreRecorded || ledger.dependencies?.NCTK !== '0.0.0' || ledger.dependencies?.PxC !== '0.0.0' || ledger.boundaries?.historicalBuildVersion !== '6.5.2' || ledger.boundaries?.canonicalPromotion !== false) {
    throw Error('Feature maturity ledger does not match the accepted 2026-10-01 composition decision.');
  }
  const historicalErratumSnapshotIsBound = digest(ledgerBytes) === erratum.corrected?.ledgerSha256
    || (ledger.historicalErratumSnapshot?.ledgerSha256 === erratum.corrected?.ledgerSha256
      && ledger.historicalErratumSnapshot?.decisionSha256 === erratum.corrected?.decisionSha256);
  if (erratum.schema !== 'discstudio-feature-maturity-citation-erratum@1' || !historicalErratumSnapshotIsBound || erratum.corrected?.decisionSha256 !== digest(decisionBytes) || !ledgerBytes.includes(erratum.corrected.verifiedPreviewSelectionDriveId) || !decisionBytes.includes(erratum.corrected.verifiedPreviewSelectionDriveId) || ledgerBytes.includes(erratum.original.previewSelectionDriveIdAsWritten) || decisionBytes.includes(erratum.original.previewSelectionDriveIdAsWritten)) {
    throw Error('Feature maturity citation erratum is inconsistent with its corrected files.');
  }
  return {
    ledger,
    ledgerBytes,
    decisionBytes,
    erratumBytes,
    binding: {
      ledger: { path: ledgerName, bytes: ledgerBytes.length, sha256: digest(ledgerBytes) },
      decision: { path: decisionName, bytes: decisionBytes.length, sha256: digest(decisionBytes) },
      erratum: { path: erratumName, bytes: erratumBytes.length, sha256: digest(erratumBytes), scope: erratum.scope },
      demoVersion: ledger.demo.version,
      stages: stages.map(stage => ({ name: stage.name, version: stage.version })),
      features: features.map(feature => ({ name: feature.name, contractVersion: feature.contractVersion, implementationVersion: feature.implementationVersion })),
      dependencies: ledger.dependencies,
      historicalBuildVersion: ledger.boundaries.historicalBuildVersion,
    },
    html: stages.map(stage => `<details class="feature-version-stage"><summary>${escapeHtml(stage.name)} · ${escapeHtml(stage.version)}</summary><ul>${stage.features.map(feature => `<li>${escapeHtml(feature.name)} · ${escapeHtml(feature.implementationVersion)} <small>(contract ${escapeHtml(feature.contractVersion)})</small></li>`).join('')}</ul></details>`).join(''),
  };
}
