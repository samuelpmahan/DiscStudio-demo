import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const escapeHtml = value => String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);

export function readFeatureMaturity(appDirectory) {
  const ledgerName = 'feature-implementation-maturity.json';
  const decisionName = 'feature-version-decision.md';
  const erratumName = 'feature-maturity-erratum.json';
  const ledgerBytes = fs.readFileSync(path.join(appDirectory, ledgerName));
  const decisionBytes = fs.readFileSync(path.join(appDirectory, decisionName));
  const erratumBytes = fs.readFileSync(path.join(appDirectory, erratumName));
  const ledger = JSON.parse(ledgerBytes);
  const erratum = JSON.parse(erratumBytes);
  const stages = ledger.demo?.stages;
  const features = stages?.flatMap(stage => stage.features ?? []);
  if (ledger.schema !== 'discstudio-feature-implementation-maturity@1' || ledger.decision !== 'ACCEPTED_PATCH_PROGRESS' || ledger.demo?.version !== '0.0.0' || stages?.length !== 3 || features?.length !== 18 || stages.some(stage => stage.version !== '0.0.0') || features.some(feature => feature.contractVersion !== '0.1.0') || features.filter(feature => feature.implementationVersion === '0.1.1').length !== 17 || features.filter(feature => feature.name === 'Preview' && feature.implementationVersion === '0.1.2').length !== 1 || ledger.dependencies?.NCTK !== '0.0.0' || ledger.dependencies?.PxC !== '0.0.0' || ledger.boundaries?.historicalBuildVersion !== '6.5.2' || ledger.boundaries?.canonicalPromotion !== false || ledger.boundaries?.sitePublished !== false) {
    throw Error('Feature maturity ledger does not match the accepted 2026-10-01 composition decision.');
  }
  if (erratum.schema !== 'discstudio-feature-maturity-citation-erratum@1' || erratum.corrected?.ledgerSha256 !== digest(ledgerBytes) || erratum.corrected?.decisionSha256 !== digest(decisionBytes) || !ledgerBytes.includes(erratum.corrected.verifiedPreviewSelectionDriveId) || !decisionBytes.includes(erratum.corrected.verifiedPreviewSelectionDriveId) || ledgerBytes.includes(erratum.original.previewSelectionDriveIdAsWritten) || decisionBytes.includes(erratum.original.previewSelectionDriveIdAsWritten)) {
    throw Error('Feature maturity citation erratum is inconsistent with its corrected files.');
  }
  return {
    ledger,
    ledgerBytes,
    decisionBytes,
    erratumBytes,
    binding: {
      ledger: { path: ledgerName, bytes: ledgerBytes.length, sha256: digest(ledgerBytes) },
      decision: { path: decisionName, bytes: decisionBytes.length, sha256: digest(decisionBytes) },
      erratum: { path: erratumName, bytes: erratumBytes.length, sha256: digest(erratumBytes), scope: erratum.scope },
      demoVersion: ledger.demo.version,
      stages: stages.map(stage => ({ name: stage.name, version: stage.version })),
      features: features.map(feature => ({ name: feature.name, contractVersion: feature.contractVersion, implementationVersion: feature.implementationVersion })),
      dependencies: ledger.dependencies,
      historicalBuildVersion: ledger.boundaries.historicalBuildVersion,
    },
    html: stages.map(stage => `<details class="feature-version-stage"><summary>${escapeHtml(stage.name)} · ${escapeHtml(stage.version)}</summary><ul>${stage.features.map(feature => `<li>${escapeHtml(feature.name)} · ${escapeHtml(feature.implementationVersion)} <small>(contract ${escapeHtml(feature.contractVersion)})</small></li>`).join('')}</ul></details>`).join(''),
  };
}
