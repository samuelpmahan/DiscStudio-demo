import { validateRefitSource,                  } from './photo-refit.js?v=29b3489a3ed5d6cc';
import { Part, PxC } from './kernel/pxc.mjs?v=29b3489a3ed5d6cc';
import { renderDiscPainting } from './paint.js?v=29b3489a3ed5d6cc';
import { validatePaintRecipe, recipeFromDraft, renderDepiction,                  } from './paint-recipe.js?v=29b3489a3ed5d6cc';
import { shelfQuery } from './shelf-query.js?v=29b3489a3ed5d6cc';
import { createBag } from './bags.js?v=29b3489a3ed5d6cc';
import { plasticGuides } from './plastics.js?v=29b3489a3ed5d6cc';
import { searchMolds, getMoldDetails, moldRecord, moldRuntimeAvailable, moldRuntimeError,                        } from './mold-library.js?v=29b3489a3ed5d6cc';
import { create, read, update, destroy, runStage,            } from './operations.js?v=29b3489a3ed5d6cc';
import { selectCalculation,                              } from './calculation-select.js?v=29b3489a3ed5d6cc';
import { find } from './devtools-data.mjs?v=29b3489a3ed5d6cc';
                                                             
import { queueCards,                 } from './export-queue-core.js?v=29b3489a3ed5d6cc';
import { approvedQueueIdentity, withApprovalInstances } from './approval-identity.js?v=29b3489a3ed5d6cc';
import { paintedDiscsEnabled } from './kompozition.js?v=29b3489a3ed5d6cc';

                                                                                                                                                                                                                                                     
export const flightFields = ['speed', 'glide', 'turn', 'fade']         ;
                                                                  
                                                                                                              
                                                                         
                                                                                                                                                                                                       
                                                                                                      
                                                                                                                                     
                                                                                         
const seedAddress = (id        ) => `ds.px.seed.${id}`;
function moldFromPacked(record                                            )       {
  return Object.freeze({ id: record.id, manufacturer: record.manufacturer, name: record.mold,
    speed: record.flight[0] ?? null, glide: record.flight[1] ?? null,
    turn: record.flight[2] ?? null, fade: record.flight[3] ?? null,
    provenance: record.provenance });
}
export const initialDraft = ()        => ({ mold: seedAddress('buzzz'), nickname: '', weight: null, plastic: '', Color1: '#98d4ba', Color2: '#f8b393', paintMode: 'split', colorPainting: false });
function checkFlights(value                  ) {
  for (const field of flightFields) if (Object.hasOwn(value, field) && value[field] !== null && !Number.isFinite(value[field])) throw Error(`${field} must be finite or null; remove the field to inherit.`);
}
function checkDraft(draft       ) {
  if (!/^ds\.px\.seed\.[\w.-]+$/.test(draft.mold)) throw new Error('Choose a seeded disc.');
  checkFlights(draft);
  if (draft.weight !== null && (!Number.isFinite(draft.weight) || draft.weight <= 0)) throw new Error('Weight must be positive grams, or blank.');
  for (const color of [draft.Color1, draft.Color2]) if (!/^#[\da-f]{6}$/i.test(color)) throw new Error('Choose two valid colors.');
  if (!['split', 'halo'].includes(draft.paintMode) || typeof draft.colorPainting !== 'boolean') throw new Error('Choose a paint mode and color setting.');
}

function isRecord(value         )                               {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}
function hasText(value         )                  { return typeof value === 'string' && value.trim().length > 0; }
function validFactValues(value                     , fields                   ) {
  return fields.every(field => !Object.hasOwn(value, field) || value[field] === null || (typeof value[field] === 'number' && Number.isFinite(value[field])));
}
function validFactsInputs(inputs                               ) {
  const seed = inputs.seed?.value, draft = inputs.draft?.value;
  return isRecord(seed) && hasText(seed.id) && hasText(seed.manufacturer) && hasText(seed.name)
    && isRecord(draft) && hasText(draft.mold) && validFactValues(seed, flightFields) && validFactValues(draft, flightFields);
}
function resolveDiscFacts(seed                     , draft                     , seedFlightShape                       ) {
  const resolved                      = { ...seed, ...draft };
  const flightFactSources                                                             = {};
  for (const field of flightFields) {
    if (Object.hasOwn(draft, field)) {
      resolved[field] = draft[field];
      flightFactSources[field] = 'draft-override';
    } else if (Object.hasOwn(seed, field)) {
      resolved[field] = seed[field];
      flightFactSources[field] = 'seed';
    } else {
      // The sparse clause materializes absent catalog facts as explicit unknowns.
      resolved[field] = null;
      flightFactSources[field] = 'missing-seed';
    }
  }
  return Object.freeze({
    ...resolved,
    flightFactSources: Object.freeze(flightFactSources),
    factResolution: Object.freeze({
      seedFlightShape,
      presentSeedFlights: Object.freeze(flightFields.filter(field => Object.hasOwn(seed, field))),
      missingSeedFlights: Object.freeze(flightFields.filter(field => !Object.hasOwn(seed, field))),
    }),
  });
}

const discFactsSelectClauses                                     = Object.freeze([
  Object.freeze({
    name: 'complete-seed-flight-facts',
    calculationAddress: 'fn.disc.resolveFacts.complete',
    matches: (inputs                               ) => validFactsInputs(inputs)
      && flightFields.every(field => Object.hasOwn(inputs.seed.value, field)),
  }),
  Object.freeze({
    name: 'sparse-seed-flight-facts',
    calculationAddress: 'fn.disc.resolveFacts.sparse',
    matches: (inputs                               ) => validFactsInputs(inputs)
      && flightFields.some(field => !Object.hasOwn(inputs.seed.value, field)),
  }),
]);

const resolveCompleteDiscFacts = ({ seed, draft }                                                           ) => resolveDiscFacts(seed, draft, 'complete');
const resolveSparseDiscFacts = ({ seed, draft }                                                           ) => resolveDiscFacts(seed, draft, 'sparse');

export function createExperience(log                                           = event => console.info(JSON.stringify(event)), options                                                                                                                                 = {}) {
  const pxc = options.state?.pxc ?? new PxC();
  if (!options.state) {
  // Fresh PxC starts without catalog rows; the immutable runtime index is outside the World.
  pxc.set('ds.px.plasticGuides', new Part(plasticGuides));
  for (const [address, implementation] of Object.entries({ 'fn.read': read, 'fn.find': find, 'oc.create': create, 'oc.update': update, 'oc.destroy': destroy,
    'fn.tick': (outputs     ) => Object.freeze({ outputs: Object.freeze(Object.keys(outputs)) }),
    'fn.disc.resolveFacts.complete': resolveCompleteDiscFacts,
    'fn.disc.resolveFacts.sparse': resolveSparseDiscFacts,
    'fn.renderPainting': renderDiscPainting,
    'fn.paintRecipe': ({ recipe }     ) => validatePaintRecipe(recipe), 'fn.renderDepiction': renderDepiction,
    'fn.shelfQuery': shelfQuery, 'fn.createBag': createBag,
    // Output is a calculated PxC collection. Each enqueue receives an exact
    // card snapshot Part, so later editor choices cannot rewrite held output.
    'fn.appendOutputQueue': ({ queue, cards }                                                                ) => queueCards([...queue, ...cards]),
    'fn.removeOutputQueueItem': ({ queue, index }                                                 ) => {
      if (!Number.isSafeInteger(index) || index < 0 || index >= queue.length) throw Error('Queued output no longer exists.');
      return queueCards(queue.filter((_, itemIndex) => itemIndex !== index));
    },
    'fn.shelfRows': ({ references, ...parts }     ) => Object.freeze(references.map((address        , i        ) => Object.freeze({ address, disc: parts[`disc${i}`], seed: parts[`seed${i}`], art: parts[`art${i}`] }))),
    'fn.addReference': ({ collection, reference, value }     ) => {
      if (!value.id || collection.includes(reference)) throw Error('Reference already retained.');
      return Object.freeze([...collection, reference]);
    },
  })) pxc.set(address, new Part(implementation));
  pxc.set('fn.addToShelf', new Part(({ shelf, reference, disc }     ) => {
    if (!disc.id || shelf.includes(reference)) throw new Error('Disc is already on the shelf.');
    return Object.freeze([...shelf, reference]);
  }));
  pxc.set('fn.addToBag', new Part(({ bag, reference, disc }     ) => {
    if (!disc.id || bag.includes(reference)) throw new Error('Disc is already in the bag.');
    return Object.freeze([...bag, reference]);
  }));
  pxc.set('ds.px.shelf.0', new Part(Object.freeze([])));
  // MVP: the bag is the primary collection. Shelf is retained for legacy.
  pxc.set('ds.px.bag.0', new Part(Object.freeze([])));
  pxc.set('ds.px.output.queue.0', new Part(Object.freeze([])));
  }
  let shelfAddress = options.state?.shelfAddress ?? 'ds.px.shelf.0', serial = options.state?.serial ?? 0;
  let bagAddress = options.state?.bagAddress ?? 'ds.px.bag.0';
  if (!pxc.entries().some(([name]                   ) => name === bagAddress)) pxc.set(bagAddress, new Part(Object.freeze([])));
  let bagsAddress = options.state?.bagsAddress ?? 'ds.px.bags.0';
  if (!pxc.entries().some(([name]                   ) => name === bagsAddress)) pxc.set(bagsAddress, new Part(Object.freeze([])));
  // Output is deliberately current-session material. It is represented in PxC
  // for calculated provenance, but a fresh launch never restores it into the
  // creator flow.
  let outputQueueAddress = 'ds.px.output.queue.0';
  if (!pxc.entries().some(([name]                   ) => name === outputQueueAddress)) pxc.set(outputQueueAddress, new Part(Object.freeze([])));
  let saving = false;
  let latestOutputApproval                                           = null;
  let latestOutputExport                                           = null;
  const events                            = [];
  const emit = (event                         ) => { events.push(event); try { log(event); } catch (error) { console.warn('Diagnostic sink failed; receipt remains in PxC.', error); } };
  const selected = new Map                   ();
  // Fresh PxC contains only selected seed Parts. Catalog lookup state is held
  // outside PxC; restored archives retain their existing addresses verbatim.
  const currentSeeds = new Map(options.state?.currentSeeds ?? []);
  const maybeSeedAt = (address        )              => {
    try { return pxc.get(address).value        ; }
    catch (error) {
      if (error instanceof Error && error.message === `Missing Part: ${address}`) return null;
      throw error;
    }
  };
  const persist = (nextShelf = shelfAddress, molds = currentSeeds, nextBags = bagsAddress, nextBag = bagAddress, commitReceipt                ) => options.persist?.({ pxc, serial, shelfAddress: nextShelf, currentSeeds: [...molds], bagsAddress: nextBags, bagAddress: nextBag, commitReceipt });
  const candidates = new Map                ();
  const artAt = (disc      ) => disc.art ?? `ds.px.art.${disc.id}`;
  async function projectRows(operationId        ) {
    const inputs                      = { references: shelfAddress };
    (pxc.get(shelfAddress).value            ).forEach((address, i) => {
      const disc = pxc.get(address).value        ;
      inputs[`disc${i}`] = address; inputs[`seed${i}`] = disc.mold; inputs[`art${i}`] = artAt(disc);
    });
    const into = `ds.px.shelf.rows.${operationId}`;
    await pxc.compose({ into, calculation: 'fn.shelfRows', inputs });
    return into;
  }
  function checkPhoto(photo                  ) {
    if (photo !== null && (photo.kind !== 'photo' || !/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+=*$/.test(photo.src))) throw Error('Invalid prepared photo.');
    if (photo?.refit !== undefined) validateRefitSource(photo.refit);
  }
  function snapshotDepiction(value           )            {
    return Object.freeze({ ...value, ...(value.refit !== undefined ? { refit: validateRefitSource(value.refit) } : {}) });
  }
  async function materializeSeed(address        , persistSelection = true)                                           {
    const existing = maybeSeedAt(address) ?? undefined;
    const id = existing?.id ?? address.replace(/^ds\.px\.seed\./, '').split('.')[0];
    const current = currentSeeds.get(id);
    if (current && current !== address) return { address: current, seed: pxc.get(current).value         };
    if (existing && flightFields.every(field => Object.hasOwn(existing, field)) && existing.provenance) return { address, seed: existing };
    const details = await getMoldDetails(id);
    if (!details) {
      if (existing) return { address, seed: existing };
      throw Error('Selected catalog mold is unavailable. Reload DiscStudio to retry.');
    }
    const source = moldFromPacked(details);
    const base = existing ?? source;
    const hydrated = Object.freeze({ ...source, ...base,
      ...Object.fromEntries(flightFields.map(field => [field, Object.hasOwn(base, field) ? base[field] : source[field]])),
      provenance: base.provenance ?? source.provenance })        ;
    // Use the stable source address for a fresh selection. If a legacy Part
    // already occupies that identity, append a new immutable corrected Part.
    const into = existing ? `ds.px.seed.${id}.selected.${++serial}` : seedAddress(id);
    pxc.set(into, new Part(hydrated)); currentSeeds.set(id, into);
    if (persistSelection) persist();
    return { address: into, seed: hydrated };
  }
  return {
    pxc, events,
    get catalogAvailable() { return moldRuntimeAvailable; },
    get catalogError() { return moldRuntimeError; },
    get persistenceStatus() { return options.status?.() ?? 'Session only · reload starts fresh.'; },
    get shelfAddress() { return shelfAddress; },
    get bagAddress() { return bagAddress; },
    get bagsAddress() { return bagsAddress; },
    get outputQueueAddress() { return outputQueueAddress; },
    seedOptions(query = '')                                    {
      // Suggestions are decoded from the compact index and never materialized
      // into PxC. Only an explicit selection creates the seed Part.
      return searchMolds(query, 20).map(record => {
        const retainedAddress = currentSeeds.get(record.id);
        const address = retainedAddress ?? seedAddress(record.id);
        // A persisted currentSeeds pointer is authoritative. Missing pointers
        // fail closed rather than silently reverting a retained correction.
        const retained = retainedAddress ? pxc.get(retainedAddress).value         : moldFromPacked(record);
        return { address, seed: retained };
      });
    },
    // UI callers inspect only exact selected/restored PxC snapshots here; this
    // never falls through to a newer catalog record.
    seedAt(address        )       { return pxc.get(address).value        ; },
    async hydrateSeed(address        ) { return materializeSeed(address); },
    resolve(disc       ) { return read({ base: pxc.get(disc.mold).value, own: disc }); },
    depictionSources(address        ) {
      const disc = pxc.get(address).value        ;
      return { recipe: disc.paintRecipe ? pxc.get(disc.paintRecipe).value                : disc.depiction.kind === 'painted' ? recipeFromDraft(disc, disc.depiction) : null,
        photo: disc.photo ? pxc.get(disc.photo).value                     : disc.depiction.kind === 'photo' ? disc.depiction : null,
        choice: disc.choice ? pxc.get(disc.choice).value                        : disc.depiction.kind };
    },
    async queryShelf(request                                              = {}) {
      const id = `query-${++serial}`, rows = await projectRows(id), into = `ds.px.shelf.query.${id}`;
      // Snapshot request arrays: later control changes must not rewrite this query's inputs.
      const snapshot = structuredClone(request);
      await pxc.compose({ into, calculation: 'fn.shelfQuery', inputs: { rows, request: new Part(snapshot) } });
      return { address: into, ...pxc.get(into).value };
    },
    bags() {
      const current = new Map((pxc.get(shelfAddress).value            ).map(address => [pxc.get(address).value.id, address]));
      return (pxc.get(bagsAddress).value            ).map(address => {
        const bag = pxc.get(address).value;
        return { address, bag, discs: bag.discIds.map((id        ) => {
          const version = current.get(id); if (!version) throw Error(`Bag disc ${id} is missing from the shelf.`);
          const disc = pxc.get(version).value        ;
          return { address: version, disc, seed: pxc.get(disc.mold).value        , art: pxc.get(artAt(disc)).value           };
        }) };
      });
    },
    async createBag(name        , selection          ) {
      if (saving) throw Error('A collection write is already in progress.');
      saving = true;
      const id = `bag-${++serial}`, into = `ds.px.bag.${id}`, next = `ds.px.bags.${id}`;
      try {
        const rows = await projectRows(id);
        await pxc.compose({ into, calculation: 'fn.createBag', inputs: { name: new Part(name), selection: new Part(Object.freeze([...selection])), rows, id: new Part(id) } });
        await pxc.compose({ into: next, calculation: 'fn.addReference', inputs: { collection: bagsAddress, reference: new Part(into), value: into } });
        const bag = pxc.get(into).value;
        if (bag.versions.length !== selection.length || bag.versions.some((v     , i        ) => v.address !== selection[i]) || pxc.get(next).value.at(-1) !== into) throw Error('Bag readback failed.');
        persist(shelfAddress, currentSeeds, next);
        bagsAddress = next;
        emit({ event: 'bag.create.completed', bagAddress: into, bagsAddress: next, discIds: bag.discIds, readbackMatched: true });
        return into;
      } finally { saving = false; }
    },
    async updateDepiction(address        , changes                                                                                                 ) {
      if (!paintedDiscsEnabled && (changes.choice === 'painted' || changes.recipe)) throw Error('Painted discs require the painted-discs overlay.');
      const disc = pxc.get(address).value        , retained = this.depictionSources(address);
      const recipeInput = changes.recipe === undefined ? retained.recipe : changes.recipe;
      const recipe = recipeInput == null ? null : validatePaintRecipe(recipeInput);
      const photo = changes.photo === undefined ? retained.photo : changes.photo;
      checkPhoto(photo);
      const choice = changes.choice ?? retained.choice;
      if (!['painted', 'photo'].includes(choice) || (choice === 'photo' && !photo) || (choice === 'painted' && !recipe)) throw Error('Choose a retained depiction source.');
      const mold = changes.mold ?? disc.mold; pxc.get(mold); checkDraft({ ...disc, mold });
      const id = `depict-${++serial}`, into = `ds.px.disc.${id}`;
      const recipeAddress = `ds.px.recipe.${id}`, photoAddress = `ds.px.photo.${id}`, choiceAddress = `ds.px.choice.${id}`, artAddress = `ds.px.art.${id}`;
      if (recipe) await pxc.compose({ into: recipeAddress, calculation: 'fn.paintRecipe', inputs: { recipe: new Part(recipe) } });
      else pxc.set(recipeAddress, new Part(null));
      pxc.set(photoAddress, new Part(photo ? snapshotDepiction(photo) : null)); pxc.set(choiceAddress, new Part(choice));
      await pxc.compose({ into: artAddress, calculation: 'fn.renderDepiction', inputs: { recipe: recipeAddress, photo: photoAddress, choice: choiceAddress, seed: mold } });
      const depiction            = choice === 'photo' ? photo  : Object.freeze({ kind: 'painted', name: recipe .family, src: `./art/${recipe .family}.svg` });
      await pxc.compose({ into, calculation: 'oc.update', inputs: { value: address, patch: new Part(Object.freeze({ mold, depiction, paintRecipe: recipeAddress, photo: photoAddress, choice: choiceAddress, art: artAddress })) } });
      candidates.set(into, address);
      return into;
    },
    async updateDisc(address        , patch                  , remove           = []) {
      if (!pxc.get(address).value.mold) throw Error('Select a Disc.');
      if ([...Object.keys(patch), ...remove].some(key => !(flightFields                     ).includes(key))) throw Error('This editor updates flight fields only.');
      checkFlights(patch);
      const into = `ds.px.disc.edit-${++serial}`;
      await pxc.compose({ into, calculation: 'oc.update', inputs: { value: address, patch: new Part(Object.freeze({ ...patch })), remove: new Part(Object.freeze([...remove])) } });
      candidates.set(into, address);
      return into;
    },
    async keepDisc(before        , candidate        ) {
      if (saving) throw Error('A shelf write is already in progress.');
      saving = true;
      const operationId = `keep-${++serial}`;
      try {
        const previousShelf = shelfAddress, members = pxc.get(previousShelf).value            ;
        const index = members.indexOf(before);
        if (index < 0 || candidates.get(candidate) !== before) throw Error('This selection changed. Reopen the current disc before keeping an edit.');
        const into = `ds.px.shelf.${operationId}`;
        await pxc.compose({ into, calculation: 'oc.update', inputs: { value: previousShelf, patch: new Part(Object.freeze({ [index]: candidate })) } });
        const actual = pxc.get(into).value            ;
        if (actual.length !== members.length || actual.some((ref, i) => ref !== (i === index ? candidate : members[i]))) throw Error('Shelf readback failed.');
        const receipt = Object.freeze({ event: 'disc.edit.kept', operationId, before, candidate, previousShelf, shelfAddress: into, readbackMatched: true, storage: 'session-memory' });
        pxc.set(`ds.px.receipt.${operationId}`, new Part(receipt));
        persist(into);
        shelfAddress = into; emit(receipt);
        return candidate;
      } finally { saving = false; }
    },
    async reviewSeed(address        , verdict                           , correction             ) {
      const seed = pxc.get(address).value        ;
      if (currentSeeds.get(seed.id) !== address) throw new Error('This seed has a newer correction. Review the current one.');
      if (!['confirmed', 'corrected'].includes(verdict)) throw new Error('Choose a review result.');
      const operationId = `review-${++serial}`;
      if (verdict === 'corrected' && !correction) throw new Error('Supply the correction.');
      const into = `ds.px.seed.${seed.id}.${operationId}`;
      const patch                      = verdict === 'confirmed' ? {} : correction ;
      checkFlights(patch);
      if (verdict === 'corrected' && (!patch.manufacturer?.trim() || !patch.name?.trim())) throw Error('Enter manufacturer and mold.');
      await pxc.compose({ into, calculation: 'oc.update', inputs: { value: address, patch: new Part(Object.freeze({ ...patch, reviewStatus: verdict })) } });
      const receipt = Object.freeze({ event: 'seed.review.completed', operationId, verdict, before: address, after: into, flight: flightFields.map(field => pxc.get(into).value[field]) });
      pxc.set(`ds.px.receipt.${operationId}`, new Part(receipt));
      persist(shelfAddress, new Map([...currentSeeds, [seed.id, into]]));
      currentSeeds.set(seed.id, into);
      emit(receipt);
      return into;
    },
    async addDraftPhoto(photo           )                  {
      checkPhoto(photo);
      const id = ++serial;
      const address = `ds.px.draft.photos.${id}`;
      pxc.set(address, new Part(snapshotDepiction(photo)));
      return address;
    },
    outputQueue()                        { return pxc.get(outputQueueAddress).value                         ; },
    get latestOutputApproval() { return latestOutputApproval; },
    get latestOutputExport() { return latestOutputExport; },
    async enqueueOutput(cards                       ) {
      const submitted = queueCards(cards);
      if (!submitted.length) throw Error('Select at least one disc before adding output.');
      const operationId = `enqueue-${++serial}`, held = await withApprovalInstances(submitted, operationId), cardsAddress = `ds.px.output.cards.${operationId}`, next = `ds.px.output.queue.${operationId}`, previousQueue = outputQueueAddress;
      pxc.set(cardsAddress, new Part(held));
      await pxc.compose({ into: next, calculation: 'fn.appendOutputQueue', inputs: { queue: outputQueueAddress, cards: cardsAddress } });
      const result = pxc.get(next).value                         ;
      if (result.length !== this.outputQueue().length + held.length || result.slice(-held.length).some((card, index) => card !== held[index] && JSON.stringify(card) !== JSON.stringify(held[index]))) throw Error('Output queue readback failed.');
      outputQueueAddress = next;
      const approved = await approvedQueueIdentity(result);
      const receipt = Object.freeze({ event: 'output.queue.approved', operationId, action: 'append', inputCards: cardsAddress, previousQueue, outputQueue: next, count: result.length, addedCount: held.length, approvalSnapshotId: approved.identity, outputQueueSnapshotId: approved.identity });
      pxc.set(`ds.px.receipt.${operationId}`, new Part(receipt)); latestOutputApproval = receipt; emit(receipt);
      return next;
    },
    async approveOutputQueue(expectedQueueAddress         ) {
      const queueAddress = outputQueueAddress;
      if (expectedQueueAddress !== undefined && expectedQueueAddress !== queueAddress) throw Error('Output queue changed during review. Review the remaining cards again.');
      const queue = this.outputQueue();
      if (!queue.length) throw Error('Approve requires at least one queued card.');
      const operationId = `approve-output-${++serial}`, approved = await approvedQueueIdentity(queue);
      if (outputQueueAddress !== queueAddress) throw Error('Output queue changed during review. Review the remaining cards again.');
      const receipt = Object.freeze({ event: 'output.queue.approved', operationId, action: 'reapprove-current-queue', outputQueue: outputQueueAddress, count: queue.length, addedCount: 0, approvalSnapshotId: approved.identity, outputQueueSnapshotId: approved.identity });
      pxc.set(`ds.px.receipt.${operationId}`, new Part(receipt)); latestOutputApproval = receipt; emit(receipt);
      return outputQueueAddress;
    },
    async validateOutputExport(expectedOutputQueueSnapshotId        ) {
      const approval = latestOutputApproval, queueAddress = outputQueueAddress;
      if (!approval) throw Error('Approve the current output queue before exporting.');
      if (!expectedOutputQueueSnapshotId || expectedOutputQueueSnapshotId !== approval.outputQueueSnapshotId) throw Error('Prepared ZIP does not match the current approval snapshot.');
      const actual = await approvedQueueIdentity(this.outputQueue());
      if (outputQueueAddress !== queueAddress || latestOutputApproval !== approval || actual.identity !== expectedOutputQueueSnapshotId) throw Error('Output queue changed after approval. Approve the current queue before exporting.');
      return actual.identity;
    },
    async recordOutputExport(exported                                                                                                                              ) {
      const identity = await this.validateOutputExport(exported.expectedOutputQueueSnapshotId);
      const operationId = `export-${++serial}`;
      const receipt = Object.freeze({ event: 'output.zip.prepared', operationId, approvalSnapshotId: latestOutputApproval .approvalSnapshotId, outputQueueSnapshotId: identity, outputQueue: outputQueueAddress, manifestId: exported.manifestId, zipId: exported.zipId, downloadRequested: exported.downloadRequested === true, manifest: exported.manifest });
      pxc.set(`ds.px.receipt.${operationId}`, new Part(receipt)); latestOutputExport = receipt; emit(receipt);
      return receipt;
    },
    async removeOutput(index        ) {
      const operationId = `remove-output-${++serial}`, next = `ds.px.output.queue.${operationId}`, previousApprovalSnapshotId = latestOutputApproval?.approvalSnapshotId ?? null;
      await pxc.compose({ into: next, calculation: 'fn.removeOutputQueueItem', inputs: { queue: outputQueueAddress, index: new Part(index) } });
      const receipt = Object.freeze({ event: 'output.queue.removed', operationId, previousQueue: outputQueueAddress, outputQueue: next, index, approvalInvalidated: !!previousApprovalSnapshotId, previousApprovalSnapshotId });
      pxc.set(`ds.px.receipt.${operationId}`, new Part(receipt)); latestOutputApproval = null; latestOutputExport = null; outputQueueAddress = next; emit(receipt);
      return next;
    },
    async selectDraftDepiction(random               = Math.random, preferPainting = false)                     {
      const id = ++serial;
      const depictionAddress = `ds.px.draft.depiction.${id}`;
      // Photo-only: the demo requires a draft photo. No painting fallback.
      const consumed = new Set([...pxc.entries()].filter(([name]) => name.startsWith('ds.px.draft.consumedPhotos.')).flatMap(([, part]) => (part.value            ) ?? []));
      const photoKeys = [...pxc.entries()].filter(([name]) => name.startsWith('ds.px.draft.photos.') && !consumed.has(name)).map(([name]) => name).sort((a, b) => Number(a.split('.').pop()) - Number(b.split('.').pop()));
      if (photoKeys.length === 0 && !paintedDiscsEnabled) throw new Error('No draft photo. Upload a photo first.');
      if (paintedDiscsEnabled && (photoKeys.length === 0 || preferPainting)) {
        const families = ['pressed-fern', 'chevron-run', 'contour-basin'];
        const name = families[Math.min(families.length - 1, Math.max(0, Math.floor(random() * families.length)))];
        const depiction            = Object.freeze({ kind: 'painted', name, src: `./art/${name}.svg` });
        pxc.set(depictionAddress, new Part(depiction)); selected.set(depiction, depictionAddress);
        return depiction;
      }
      const photo = pxc.get(photoKeys[photoKeys.length - 1]).value             ;
      const depiction = snapshotDepiction(photo);
      pxc.set(depictionAddress, new Part(depiction));
      selected.set(depiction, depictionAddress);
      return depiction;
    },
    async save(draft       , depiction           , sources                   = {}) {
      if (saving) throw new Error('A save is already in progress.');
      saving = true;
      const operationId = `save-${++serial}`;
      const discAddress = `ds.px.disc.${operationId}`, nextShelf = `ds.px.shelf.${operationId}`, nextBag = `ds.px.bag.${operationId}`;
      const expectedShelfHead = shelfAddress, expectedBagHead = bagAddress;
      try {
        checkDraft(draft);
        // Preserve the existing direct-save(initialDraft()) contract while
        // keeping fresh PxC sparse until an explicit selection/save boundary.
        const selectedSeed = await materializeSeed(draft.mold, false);
        draft = { ...draft, mold: selectedSeed.address };
        if (depiction.kind !== 'photo' && (!paintedDiscsEnabled || depiction.kind !== 'painted')) throw new Error('Demo is photo-only. Upload a photo.');
        if (depiction.kind === 'photo' && !/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+=*$/.test(depiction.src)) throw new Error('Invalid prepared photo.');
        const draftAddress = `ds.px.draft.${operationId}`, depictionAddress = `ds.px.depiction.${operationId}`;
        pxc.get(draft.mold);
        pxc.set(draftAddress, new Part(Object.freeze({ ...draft })));
        const selectedFacts = selectCalculation(pxc, 'disc.facts.resolve', discFactsSelectClauses, { seed: draft.mold, draft: draftAddress });
        const selectedFactsBindingAddress = `ds.px.binding.${operationId}.resolvedFacts`;
        pxc.set(selectedFactsBindingAddress, selectedFacts.calculation);
        const selectedAddress = selected.get(depiction);
        pxc.set(depictionAddress, selectedAddress ? pxc.get(selectedAddress) : new Part(snapshotDepiction(depiction)));
        const artAddress = `ds.px.art.${operationId}`;
        const recipe = depiction.kind === 'painted'
          ? validatePaintRecipe(sources.recipe ?? recipeFromDraft(draft, depiction))
          : null;
        const photo = sources.photo === undefined ? depiction.kind === 'photo' ? depiction : null : sources.photo;
        checkPhoto(photo);
        if (depiction.kind === 'photo' && (!photo || photo.src !== depiction.src || JSON.stringify(photo.refit ?? null) !== JSON.stringify(depiction.refit ?? null))) throw Error('Selected photo must match the retained source.');
        const recipeAddress = `ds.px.recipe.${operationId}`, photoAddress = `ds.px.photo.${operationId}`, choiceAddress = `ds.px.choice.${operationId}`;
        if (!recipe) pxc.set(recipeAddress, new Part(null));
        pxc.set(photoAddress, new Part(photo ? snapshotDepiction(photo) : null));
        pxc.set(choiceAddress, new Part(depiction.kind));
        const selectionReceiptAddress = `ds.px.receipt.select.${operationId}`;
        const selectFactsTickAddress = `ds.px.tick.${operationId}.selectFacts`;
        const resolvedFactsAddress = `ds.px.resolved.${operationId}`;
        const stage        = [
          { into: selectFactsTickAddress, calculations: [{ into: resolvedFactsAddress, calculation: selectedFactsBindingAddress, inputs: selectedFacts.inputPartAddresses }] },
          { into: `ds.px.tick.${operationId}.specialize`, calculations: [
            ...(recipe ? [{ into: recipeAddress, calculation: 'fn.paintRecipe', inputs: { recipe: new Part(recipe) } }] : []),
            { into: discAddress, calculation: 'oc.create', inputs: { value: draftAddress, id: new Part(operationId), depiction: depictionAddress, paintRecipe: new Part(recipeAddress), photo: new Part(photoAddress), choice: new Part(choiceAddress), art: new Part(artAddress) } },
          ] },
          { into: `ds.px.tick.${operationId}.depict`, calculations: [{ into: artAddress, calculation: 'fn.renderDepiction', inputs: { recipe: recipeAddress, photo: photoAddress, choice: choiceAddress, seed: draft.mold } }] },
          { into: `ds.px.tick.${operationId}.retain`, calculations: [
            { into: nextShelf, calculation: 'fn.addToShelf', inputs: { shelf: expectedShelfHead, reference: new Part(discAddress), disc: discAddress } },
            { into: nextBag, calculation: 'fn.addToBag', inputs: { bag: expectedBagHead, reference: new Part(discAddress), disc: discAddress } },
          ] },
        ];
        pxc.set(`ds.px.stage.${operationId}`, new Part(Object.freeze(stage)));
        for await (const boundary of runStage(pxc, stage)) {
          if (boundary === selectFactsTickAddress) {
            const resolved = pxc.get(resolvedFactsAddress);
            if (resolved.composition?.calculation !== selectedFacts.calculation) throw Error('SELECT bound a different Calculation than it composed.');
            const selectionReceipt = Object.freeze({
              event: 'pxc.select.completed',
              query: selectedFacts.query,
              clause: selectedFacts.clause,
              calculationAddress: selectedFacts.calculationAddress,
              boundCalculationAddress: selectedFactsBindingAddress,
              inputPartAddresses: selectedFacts.inputPartAddresses,
              outputAddress: resolvedFactsAddress,
              calculationInvoked: resolved.composition.calculation === selectedFacts.calculation,
            });
            pxc.set(selectionReceiptAddress, new Part(selectionReceipt));
            emit(selectionReceipt);
          }
        }
        const disc = pxc.get(discAddress).value        ;
        const shelf = pxc.get(nextShelf).value            ;
        const bag = pxc.get(nextBag).value            ;
        const expected = { ...draft, id: operationId, depiction, paintRecipe: recipeAddress, photo: photoAddress, choice: choiceAddress, art: artAddress };
        const previousShelf = pxc.get(expectedShelfHead).value            ;
        const previousBag = pxc.get(expectedBagHead).value            ;
        if (JSON.stringify(disc) !== JSON.stringify(expected)
          || shelf.length !== previousShelf.length + 1 || shelf.some((address, index) => address !== (index === previousShelf.length ? discAddress : previousShelf[index]))
          || bag.length !== previousBag.length + 1 || bag.some((address, index) => address !== (index === previousBag.length ? discAddress : previousBag[index]))) throw new Error('Save readback failed.');
        // Candidate Parts can exist without publication. Only these two heads
        // define the visible collection; compare both before writing either.
        if (shelfAddress !== expectedShelfHead || bagAddress !== expectedBagHead) throw Error('UploadDiscToShelf collection heads changed before commit.');
        const receiptBase = Object.freeze({ event: 'disc.save.completed', operationId, calculation: 'fn.addToShelf', discAddress, expectedShelfHead, expectedBagHead, shelfAddress: nextShelf, bagAddress: nextBag, artAddress, selectionReceiptAddress, selectedClause: selectedFacts.clause, selectedCalculationAddress: selectedFacts.calculationAddress, ticks: stage.map(tick => tick.into), paintMode: disc.paintMode, colorPainting: disc.colorPainting, seedAddress: disc.mold, depictionRef: disc.depiction.src.startsWith('data:') ? 'local-photo' : disc.depiction.src, readbackMatched: true, shelfContainsDisc: true, bagContainsDisc: true });
        const receiptAddress = `ds.px.receipt.${operationId}`;
        const outcome = persist(nextShelf, currentSeeds, bagsAddress, nextBag, {
          address: receiptAddress, value: { ...receiptBase, storage: 'browser-archive' },
        });
        const receipt = Object.freeze({ ...receiptBase, storage: outcome?.storage ?? 'session-memory' });
        pxc.set(receiptAddress, new Part(receipt));
        // Do not consume a retryable draft until a save has either reached the
        // durable archive or been explicitly accepted as this-tab-only work.
        // Unexpected persistence failures still leave the photo retryable.
        const photoKeys = [...pxc.entries()].filter(([name]) => name.startsWith('ds.px.draft.photos.')).map(([name]) => name);
        if (photoKeys.length > 0) pxc.set(`ds.px.draft.consumedPhotos.${operationId}`, new Part(Object.freeze(photoKeys)));
        shelfAddress = nextShelf;
        bagAddress = nextBag;
        emit(receipt);
        return discAddress;
      } catch (error) {
        emit({ event: 'disc.save.failed', operationId, message: String(error) });
        throw error;
      } finally { saving = false; }
    },
    shelf(query = '')                                                             {
      const collection = pxc.get(shelfAddress).value.map((address        ) => {
        const disc = pxc.get(address).value        ;
        return { address, disc, seed: pxc.get(disc.mold).value, art: pxc.get(artAt(disc)).value };
      });
      // Shelf navigation uses shared disc facts. Nickname is retained for final
      // recognition in the inspector, never an index or a search field.
      return find({ collection, query: query.replace(/[·•,]/g, ' '), fields: (row     ) => [row.seed.manufacturer, row.seed.name, row.disc.plastic, String(row.disc.weight ?? '')] });
    },
    // MVP: the bag is the primary collection. Mirrors shelf() for the MVP path.
    bag(query = '')                                                             {
      // The Bag holds physical Disc identity; a kept Shelf version becomes
      // today's current depiction and facts without erasing historical Parts.
      const current = new Map((pxc.get(shelfAddress).value            ).map(address => [pxc.get(address).value.id, address]));
      const collection = pxc.get(bagAddress).value.map((held        ) => {
        const address = current.get(pxc.get(held).value.id);
        if (!address) throw Error(`Bag disc ${held} is missing from the shelf.`);
        const disc = pxc.get(address).value        ;
        return { address, disc, seed: pxc.get(disc.mold).value, art: pxc.get(artAt(disc)).value };
      });
      return find({ collection, query: query.replace(/[·•,]/g, ' '), fields: (row     ) => [row.seed.manufacturer, row.seed.name, row.disc.plastic, String(row.disc.weight ?? '')] });
    },
  };
}
// {?} Persist the retained compositions across reload; this first shelf is session-local.
