export const moldRuntimeManifest = Object.freeze({
  "schema": 1,
  "catalogVersion": "6.5.3",
  "sourceCatalogSha256": "40c30c8599e9d7b396de23bb07a722ae20812e03ea0b18a9cf2d228feecdfa6c",
  "dictionarySha256": "a76ad385fbf1ae830c4f37beb521a0b61ac1e5be4c2aa1f78e746f6d8d7b653d",
  "payloadSha256": "4299c011d4293d12dac6f833dffce119724f4fd2e3568fbb43c77a998b8cf2e9",
  "wildcardTrieSha256": "4662a8afa709741b412c1d1bdabfb649a3a2cc0191033630b37cc2783dc252dd",
  "assetSha256": "03fd92167969f79398119f0917fb52c683908a9bcca25dba1615dabeae25c1fc",
  "recordCount": 724,
  "byteLength": 45688,
  "headerBytes": 176,
  "normalizer": "MOLD-WILD1",
  "stableIdExceptions": 10,
  "wildcardTrieBytes": 35864,
  "wildcardTrieNodes": 2852
});
