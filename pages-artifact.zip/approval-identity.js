import { queueCards,                 } from './export-queue-core.js?v=144b14080cab4e06';

const utf8 = new TextEncoder();

export async function sha256Identity(value         )                  {
  const bytes = utf8.encode(JSON.stringify(value));
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return `sha256:${[...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('')}`;
}

export async function approvedQueueIdentity(cards                       )                                                              {
  const snapshot = queueCards(cards);
  return Object.freeze({ cards: snapshot, identity: await sha256Identity(snapshot) });
}
