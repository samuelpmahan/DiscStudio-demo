import { mountUpload } from './upload-ui.js?v=1b442cfa0e9048b5';
import { mountExport } from './export-ui.js?v=1b442cfa0e9048b5';
                                                   

// The public page deliberately has no inspector, sandbox, or review-guide imports.
export async function mountExperiencePageShare(experience                                     ) {
  const root = document.querySelector('main') ;
  const notice = document.createElement('p');
  notice.id = 'persistence-status';
  notice.setAttribute('role', 'status');
  root.prepend(notice);
  const showPersistence = () => {
    const status = experience.persistenceStatus;
    const text = status.startsWith('Saved on this browser') ? 'Today’s Bag saved on this device; approved output is current-session only.'
      : status.startsWith('Restored Today’s Bag') ? 'Today’s Bag restored; approved output starts empty.'
      : status.startsWith('Fresh Bag') ? 'New Bag; saved discs reopen after reload.' : status;
    notice.textContent = text;
    document.getElementById('status') .textContent = text;
  };
  showPersistence();
  document.addEventListener('click', () => setTimeout(showPersistence, 0));
  document.addEventListener('submit', () => setTimeout(showPersistence, 0));
  root.querySelector('.shelf-section') .remove();
  await mountUpload({ root, experience, onSaved: () => document.dispatchEvent(new CustomEvent('discstudio:bag-changed')) });
  mountExport(experience, { root });
}
