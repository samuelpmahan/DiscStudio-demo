// Shared plain-text operation: collection and searchable fields are explicit.
export function find({ collection, query = '', fields }) {
  const tokens = query.toLocaleLowerCase().trim().split(/\s+/).filter(Boolean);
  return collection.filter(row => {
    const text = fields(row).join(' ').toLocaleLowerCase();
    return tokens.every(token => text.includes(token));
  });
}
