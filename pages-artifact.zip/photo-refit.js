/** Local source pixels and accepted geometry, independent of original file bytes. */
                                                                                                                                                                   
                                                                                                                       
export const localPhotoPattern = /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/]+=*$/;
export function validateRefitSource(value             )              {
  if (!value || value.version !== 1 || typeof value.src !== 'string' || !localPhotoPattern.test(value.src)) throw Error('Invalid retained re-fit source.');
  const { width, height, centerX, centerY, radius, rotation } = value;
  if (![width, height].every(n => Number.isSafeInteger(n) && n > 0) || ![centerX, centerY, radius, rotation].every(Number.isFinite) || radius <= 0 || centerX < radius || centerY < radius || centerX + radius > width + 1e-7 || centerY + radius > height + 1e-7) throw Error('Invalid retained re-fit geometry.');
  return Object.freeze({ version: 1, src: value.src, width, height, centerX, centerY, radius, rotation });
}
export function retainedSourceBounds(width        , height        , crop                 ) {
  const centerX = crop.centerX * width, centerY = crop.centerY * height, radius = crop.radiusX * width;
  if (![width, height, centerX, centerY, radius].every(Number.isFinite) || width <= 0 || height <= 0 || radius <= 0 || Math.abs(radius - crop.radiusY * height) > 1e-7 || centerX < radius || centerY < radius || centerX + radius > width + 1e-7 || centerY + radius > height + 1e-7) throw Error('Photo needs a bounded source circle.');
  const x = Math.max(0, Math.floor(centerX - 1.5 * radius)), y = Math.max(0, Math.floor(centerY - 1.5 * radius));
  const right = Math.min(width, Math.ceil(centerX + 1.5 * radius)), bottom = Math.min(height, Math.ceil(centerY + 1.5 * radius));
  return { x, y, width: right - x, height: bottom - y, centerX: centerX - x, centerY: centerY - y, radius };
}
/** Construct both handoff values before the caller changes its committed draft. */
export function prepareCirclePhoto(source                   , width        , height        , crop                 , name        , canvasFactory                          = () => document.createElement('canvas'), retained              ) {
  const bounds = retainedSourceBounds(width, height, crop), size = Math.max(1, Math.floor(2 * bounds.radius));
  const canvas = canvasFactory(); canvas.width = size; canvas.height = size;
  const ctx = canvas.getContext('2d'); if (!ctx) throw Error('Photo canvas unavailable.');
  ctx.save(); ctx.beginPath(); ctx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2); ctx.clip();
  ctx.translate(size / 2, size / 2); ctx.rotate(crop.rotation); ctx.scale(size / (2 * bounds.radius), size / (2 * bounds.radius)); ctx.translate(-crop.centerX * width, -crop.centerY * height); ctx.drawImage(source, 0, 0); ctx.restore();
  const src = canvas.toDataURL('image/webp', .95); if (!localPhotoPattern.test(src)) throw Error('Prepared photo could not be encoded.');
  let refit             ;
  if (retained) {
    // A later correction keeps all retained surroundings, avoiding repeated narrowing.
    if (retained.width !== width || retained.height !== height) throw Error('Re-fit source dimensions differ.');
    refit = validateRefitSource({ ...retained, centerX: crop.centerX * width, centerY: crop.centerY * height, radius: bounds.radius, rotation: crop.rotation });
  } else {
    const context = canvasFactory(); context.width = bounds.width; context.height = bounds.height;
    const context2d = context.getContext('2d'); if (!context2d) throw Error('Re-fit canvas unavailable.');
    context2d.drawImage(source, bounds.x, bounds.y, bounds.width, bounds.height, 0, 0, bounds.width, bounds.height);
    refit = validateRefitSource({ version: 1, src: context.toDataURL('image/webp', .94), width: bounds.width, height: bounds.height, centerX: bounds.centerX, centerY: bounds.centerY, radius: bounds.radius, rotation: crop.rotation });
  }
  return Object.freeze({ kind: 'photo'         , name, src, refit });
}
